---
name: pytorch-sqlite-memory
description: Build PyTorch models (MLP, Transformer or LSTM) that keep a continual-learning "memory" of their trained weights in a SQLite database, loaded back by memory name. Inspired by the NumPy-based AbstractIntegratedModule framework, but generates only database_init(), save_memory(), load_memory() and the user's own PyTorch model, never the whole framework. Use this skill whenever the user wants a PyTorch model that saves weights after training and reloads them later by name, resumes or continues training from saved weights, keeps separate weight memories per task, uses SQLite for model weights or checkpoints, or wants an AbstractIntegratedModule-style / "continual learning with memory" model in PyTorch, even if they never say "skill" or "SQLite". Supported architectures are MLP, Transformer and LSTM only, and only the one architecture requested is built.
---

# PyTorch + SQLite weight memory

Generate a PyTorch model whose trained weights are stored in SQLite as a named, auditable
**memory**, following the design of AbstractIntegratedModule (a NumPy framework). The user
trains once, saves the weights under a memory name, and on a later run loads that name to
skip training or to continue training from the refined weights instead of from scratch.

## What to generate, and what not to

Generate exactly these pieces, tailored to the user's task:

| Piece | Purpose |
|---|---|
| `database_init()` | create `activity_log.db` and the weight table if missing |
| `save_memory(model, memory_name)` | store weights **after training is done** |
| `load_memory(model, memory_name)` | separate call that restores weights by name |
| `list_memories()` | show every saved version, so old ones can be found and loaded |
| the PyTorch model | built by the factory of the **one** requested architecture: `create_mlp_with_sqlite_memory()`, `create_transformer_with_sqlite_memory()` or `create_lstm_with_sqlite_memory()` |

`save_memory` is not in the original shortlist of three, but `load_memory` has nothing to
load without it, so it always ships alongside.

The source framework also has P2P agents, async prediction managers, ensemble weighting,
explainability, SNN, kNN-augmented transformers, AWE/QAT and cross-session export. None of
that belongs here. Add one only if the user explicitly asks for it by name.

## Build only the architecture the user asked for

Every request gets **exactly one architecture**: the one the user named, or the one you
recommend when they asked for advice. Never generate MLP, Transformer and LSTM together,
whether "for completeness", "so you can compare", or as a menu. Unrequested models are code
the user has to read, run and maintain, and they bury the one that was asked for.

- **Copy only that architecture's files**: `templates/memory.py`, `templates/<arch>/`, and
  `scripts/verify_<arch>.py`. Never copy `templates/` wholesale (no `cp -r templates/*`), and
  do not open the references or templates of the other two architectures.
- **User did not name an architecture:** pick one only when the request or a file they gave
  you shows it (a described or attached dataset of flat feature rows → MLP, ordered windows
  or time series → LSTM), and say so in one line. A bare request with no data gives no such
  evidence, so ask (workflow step 1). A question like "which model should I use?" is
  answered with a recommendation and the reason, not with three implementations.
- **User names two** (for example "an MLP and an LSTM"): build exactly those two, each in its
  own self-contained folder (`mlp/`, `lstm/`) with its own copy of the files, because the
  files import each other as `model` and `train`. Do not add the third.
- **Later asks for another architecture:** add it then, not before.

## Why the design looks like this

These behaviours come from the framework and are the point of the skill, so keep them even
when simplifying:

- **Memory name is the key.** One name per task (`"churn_v1"`, `"sensor_regression"`).
  Training a new task under a new name leaves the earlier memories untouched, which is how
  the framework avoids overwriting old knowledge. Re-using a name means "same task, keep
  refining".
- **Save and load are separate calls.** `load_memory` returns `False` when nothing is saved
  yet, and the script then trains and saves. This is the framework's
  `memory_loaded` / `if not memory_loaded: train` workflow.
- **Weights are saved after training, once.** Not per epoch. A mid-training row would put a
  half-trained model in the memory a later run trusts.
- **Nothing is deleted.** A new save marks the previous version `is_active = 0` and inserts
  a new active row. The user can see every version with `list_memories()`, load an old one
  with `load_memory(..., version=id)`, or query the file with plain SQL. The framework calls
  this "auditable and transparent".
- **The database is a plain SQLite file** named `activity_log.db`, the same fixed name the
  framework uses, stored **next to `memory.py`** rather than in the current working directory
  (the framework does the same). Launching a script from another folder therefore cannot
  create a second, empty database. The model weights live in their own table,
  `torch_weight_storage`, so the file can be shared with the NumPy framework without the two
  reading each other's rows.

## Workflow

1. **Confirm the spec before creating anything.** Do not write, copy or run a single file
   until all five of these are known:

   | Needed | Example |
   |---|---|
   | architecture | MLP, Transformer or LSTM |
   | task | classification or regression |
   | input size | number of features, or `(T, F)` for sequences |
   | output size | number of classes, or number of targets |
   | memory name | `churn_v1` |

   Each can come from the user's message, or from a dataset or file they point you to
   (read it to get the shapes). None may come from guessing. A request such as "create a
   continual learning model in PyTorch with external memory" states none of the five, so the
   correct first reply is **a question, not code**, and Claude must not default to an MLP
   because it is the simplest.

   Ask for everything that is missing in **one message**, with a default offered for each so
   the user can answer "defaults": architecture (MLP for flat feature rows, LSTM for ordered
   windows, Transformer only when asked for), task, sizes (or a path to their data), and
   memory name (`<task>_v1`). Use the environment's structured question tool if it has one
   (for example AskUserQuestion in Claude Code); otherwise plain text. Asking is the whole
   turn: create no files before the answers arrive.

   The only exception is an explicit delegation: if the user says to choose for them or asks
   for a demo, build an MLP on synthetic data and state the assumptions in one line.
2. **Unsupported architecture** (CNN, GRU, GNN, diffusion, SNN, ...): say plainly that this
   skill covers MLP, Transformer and LSTM, and suggest the closest fit (LSTM for ordered
   sequences, MLP for flat features). Do not silently substitute.
3. **Read only the matching reference** before writing the model:

   | Architecture | Read | Provides |
   |---|---|---|
   | MLP | `references/mlp.md` | `create_mlp_with_sqlite_memory()` |
   | Transformer | `references/transformer.md` | `create_transformer_with_sqlite_memory()` |
   | LSTM | `references/lstm.md` | `create_lstm_with_sqlite_memory()` |

   The references explain the architecture: the `config` keys it must expose, how to choose
   parameters, and gotchas. The code itself is in the bundled files (next section).
4. **Copy the bundled files for that one architecture into the user's project**, then adapt
   them (next two sections), and tell the user where they went.
5. **Verify** (checklist below) when a Python environment is available.

## Bundled files: copy them, do not retype them

The code is tested once and lives in files, so copy it with `cp` instead of regenerating it
from memory. That keeps every project identical and avoids transcription slips.

| Copy | To (in the user's project) | Then |
|---|---|---|
| `templates/memory.py` | `memory.py` | leave as is (see below) |
| `templates/<arch>/model_mlp.py` | `model_mlp.py` | MLP Model for users who wants to creat Continual learning MLP Model (ignore if users didn't ask for it), adapt: defaults, `class_names`, sizes |
| `templates/<arch>/model_transformer.py` | `model_transformer.py` | Transformer Model for users who wants to creat Continual learning Transformer Model (ignore if users didn't ask for it), adapt: defaults, `class_names`, sizes |
| `templates/<arch>/model_lstm.py` | `model_lstm.py` | LSTM Model for users who wants to creat Continual learning LSTM Model (ignore if users didn't ask for it), adapt: defaults, `class_names`, sizes |
| `templates/<arch>/training_mlp.py` | `training_mlp.py` | MLP Training setup example (Only used when user asked for creating Continual learning MLP architecture), adapt the `__main__` block: load the user's data |
| `templates/<arch>/train_tf.py` | `train_tf.py` | Transformer Training setup example (Only used when user asked for creating Continual learning Transformer architecture), adapt the `__main__` block: load the user's data |
| `templates/<arch>/training_lstm.py` | `training_lstm.py` | LSTM Training setup example (Only used when user asked for creating Continual learning LSTM architecture), adapt the `__main__` block: load the user's data |
| `scripts/verify_<arch>.py` | same name | leave as is, then run it |


`<arch>` is the **one** architecture being built (`mlp`, `transformer` or `lstm`); the
other two folders stay untouched. The Transformer's verify script is `verify_tf.py`. All files go in one folder because they import each other by name
(`from memory import ...`, `from model import ...`, `from train import ...`). Merge into a
single file only if the user asks for one script.


In `train_<arch>.py` the line `X, y = ..., ...` is a placeholder. Replace it with the user's real
data loading before anything runs.

## Where files go, and what to tell the user

- **Location.** Use the path the user gave. If they gave none, create a new folder in the
  current working directory named after the work, such as `<memory_name>_<arch>/`
  (`churn_v1_mlp/`), and put every file there. Do not scatter files into the working
  directory itself, and never overwrite an existing `memory.py`, `model.py` or `train.py`:
  if the target folder already has one, choose a different folder name.
- **Always say where the files went.** The final reply must give the **absolute path** of the
  folder (resolve it, for example with `pwd`; never write "the current directory" or a
  relative path) and say that the files are saved on the user's own computer, on the local
  disk. Do this even when the user chose the path themselves.
- **List the files** in that folder, one short line each (`memory.py`: saves and loads the
  weights in SQLite, and so on).
- **Say where the memories will live.** `activity_log.db` does not exist yet. It is created
  next to `memory.py`, in that same folder, the first time `database_init()` runs.
- **Say how to run it**: the exact commands, starting with `cd <that path>`, then
  `python train.py` and `python verify_<arch>.py`. If `train.py` still contains the data
  placeholder, say it must be filled in first.

Put the path first and keep the rest short.

## What `memory.py` does, and why

`memory.py` provides `database_init()`, `save_memory()`, `load_memory()`, `list_memories()` and
`MemoryIncompatibleError`. Change `DB_PATH` only if the user asks. Everything else is
deliberate:

- `list_memories(memory_name=None, model_type=None)` returns the saved versions, newest
  first, as dicts (`id`, `memory_name`, `model_type`, `is_active`, `created_at`, `size_bytes`,
  `config`) without loading any weights. `load_memory(model, name, version=id)` restores that
  exact version; with no `version` it loads the active one. **Rolling back** is a load of the
  old version followed by `save_memory`, which stores those weights as a new active version
  and keeps the whole history. Tell the user about these two when they ask how to see or
  restore earlier versions; do not add them to `train.py` unasked.

- The database path is anchored to the folder containing `memory.py`, not to the working
  directory, so memories are found no matter where the script is launched from.
- `save_memory` raises on NaN/Inf weights, because a diverged model saved as "the memory"
  poisons every later run.
- `load_memory` distinguishes two cases on purpose. *No memory yet* returns `False`.
  *A memory exists but does not fit* raises `MemoryIncompatibleError`. If it only returned
  `False`, the script would retrain and `save_memory` would quietly retire a perfectly good
  memory just because someone changed a hidden size.
- Checks run before `load_state_dict`, because PyTorch can copy some tensors before it
  reports a shape error. This mirrors the framework's all-or-nothing restore.
- `weights_only=True` keeps `torch.load` from executing pickled code out of a database file.

## The contract the model must satisfy

`save_memory` and `load_memory` rely on one attribute, so every generated model needs it:

```python
model.config = {"architecture": "mlp", ...}   # JSON-serialisable
```

- `architecture` is one of `"mlp"`, `"transformer"`, `"lstm"`.
- Put in **structure** only: whatever changes parameter shapes or layer meaning (input and
  output sizes, hidden sizes, number of layers, heads, `d_model`, input shape, task type,
  bidirectional flag). These must match for a load to succeed.
- Keep **training hyperparameters** out (learning rate, epochs, batch size, dropout).
  They do not change what the weights mean, and the user should be free to tune them when
  continuing training.
- If the model depends on state that lives outside the weights (feature scaler mean/std,
  class-label order), store it as a registered buffer
  (`self.register_buffer("x_mean", ...)`) so it travels inside `state_dict`, or put the
  label map in `config`. Weights restored next to a different scaler or label order give
  silently wrong predictions.
- The `create_*` functions return a plain CPU `nn.Module`. The script moves it to a device
  after `load_memory`, never before saving.

## `train.py` shape

This is an **outline of the flow, not a file to save**: the `...` placeholders do not run.
The real `train.py` (a `train_<arch>()` function plus this flow) is `templates/<arch>/train.py`.

```python
from memory import database_init, load_memory, save_memory
from model import create_mlp_with_sqlite_memory      # or transformer / lstm

MEMORY_NAME = "my_task_v1"
CONTINUE_TRAINING = False     # True = keep refining the loaded weights

def train(model, X, y): ...   # the reference defines this, e.g. train_mlp()

if __name__ == "__main__":
    database_init()
    model = create_mlp_with_sqlite_memory(...)
    memory_loaded = load_memory(model, MEMORY_NAME)

    if not memory_loaded or CONTINUE_TRAINING:
        train(model, X, y)                   # full training loop
        save_memory(model, MEMORY_NAME)      # once, after training
    else:
        print("memory loaded, skipping training")

    probs = model.predict(X)
```

Keep everything that runs behind `if __name__ == "__main__":`. The verify scripts do
`from train import train_<arch>`, and unguarded top-level code would execute (and train, and
write to the database) just by importing the file.

Two patterns worth offering when the user mentions continual learning:

- **Continue the same task:** `CONTINUE_TRAINING = True` with the same name. A new version is
  saved and the old one stays in history.
- **Start a new task from old knowledge:** `load_memory(model, "task_A")`, train on task B,
  then `save_memory(model, "task_B")`. Task A stays exactly as it was. The shapes must match,
  so this only works when both tasks share the architecture config.

Be honest about the limit: SQLite memory preserves *saved* weights. It does not stop a model
from forgetting task A while it trains on task B under one name. The per-task memory name is
what protects the old knowledge, not any regularisation inside the training loop.

## Verify

Run this when a Python environment with torch exists; skip silently otherwise and tell the
user it was not run. 

Important Note before generating `verify_<arch>.py`: 
- recheck `from training_mlp import train_mlp` inside `verify_mlp.py` if user asked to create a continual learning Pytorch MLP, change `from training_mlp import train_mlp` to `from train import train_mlp` that matched `train.py` file name, OR just change `train.py` to `training_mlp.py` if user asked for MLP architecture.
- recheck `from training_lstm import train_lstm` inside `verify_lstm.py` if user asked to create a continual learning Pytorch LSTM, change `from training_lstm import train_lstm` to `from train import train_lstm` that matched `train.py` file name, OR just change `train.py` to `training_lstm.py` if user asked for LSTM architecture.
- recheck `from train_tf import train_tf` inside `verify_tf.py` if user asked to create a continual learning Pytorch Transformer, change `from train_tf import train_transformer` to `from train import train_transformer` that matched `train.py` file name, OR just change `train.py` to `train_tf.py` if user asked for Transformer architecture.

Copy `scripts/verify_<arch>.py` next to the project files and run
`python verify_<arch>.py`. It uses a throwaway database, so it never touches the user's real
memories, and it covers:

1. Build the model, train 1-2 steps on random tensors, `save_memory`.
2. Build a **fresh** model with the same config, `load_memory`, and assert every tensor in
   `state_dict()` equals the original.
3. Build a model with a different hidden size and assert `MemoryIncompatibleError`.
4. Save twice and check the table holds one `is_active = 1` row and one `is_active = 0` row
   for that name.
5. `list_memories` shows both versions newest first, `load_memory(version=...)` restores the
   old weights exactly, a version that does not exist raises `ValueError`, and a rollback
   (load old, save again) makes the old weights the new active version.


## Things to avoid

- Calling `save_memory` inside the epoch loop.
- Saving the optimizer by default. The framework recreates its optimizer after a load, and
  weights-only keeps the memory small and architecture-clean. Offer optimizer state only on
  request, as a separate column or table.
- Using string-built SQL; keep the `?` placeholders.
- Pickling the whole model object (`torch.save(model)`); always the `state_dict`.
- Inventing extra framework features (ensembles, P2P, async) the user did not ask for.
- Generating, copying or even reading the architectures the user did not ask for.