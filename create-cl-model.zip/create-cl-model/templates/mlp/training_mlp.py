"""train.py -- training loop and entry script for the MLP."""
import numpy as np
import torch
import torch.nn as nn

from memory import database_init, load_memory, save_memory
from model_mlp import create_mlp_with_sqlite_memory, _as_2d, _as_targets


def train_mlp(model, X, y, epochs=200, lr=0.01, momentum=0.9, batch_size=32,
              clip_norm=5.0, val_fraction=0.2, device="cpu", seed=42):
    """Plain supervised loop. Returns {'train': [...], 'val': [...]} loss history."""
    cfg = model.config
    X = _as_2d(X, cfg["input_dim"])
    if cfg["task"] == "classification":
        y = torch.as_tensor(np.asarray(y))
        if y.ndim == 2 and y.shape[1] == cfg["output_dim"]:
            y = y.argmax(1)                              # accept one-hot
        y = y.reshape(-1).long()
        if len(y) and (y.min() < 0 or y.max() >= cfg["output_dim"]):
            raise ValueError(f"labels span {int(y.min())}..{int(y.max())}, "
                             f"but output_dim={cfg['output_dim']}")
        loss_fn = nn.CrossEntropyLoss()
    else:
        y = _as_targets(y, cfg["output_dim"])
        y = model.normalize_y(y.to(model.y_mean.device))   # train in normalised space
        loss_fn = nn.MSELoss()
    if len(X) != len(y):
        raise ValueError(f"X has {len(X)} samples but y has {len(y)}")

    g = torch.Generator().manual_seed(seed)
    idx = torch.randperm(len(X), generator=g)
    n_val = int(len(X) * val_fraction) if len(X) >= 4 else 0   # too few samples: no validation
    val_idx, tr_idx = idx[:n_val], idx[n_val:]

    model.to(device)
    X, y = X.to(device), y.to(device)
    opt = torch.optim.SGD(model.parameters(), lr=lr, momentum=momentum)   # fresh optimizer every run
    history = {"train": [], "val": []}
    for epoch in range(epochs):
        model.train()
        perm = tr_idx[torch.randperm(len(tr_idx), generator=g)]
        total = 0.0
        for i in range(0, len(perm), batch_size):
            b = perm[i:i + batch_size]
            opt.zero_grad()
            loss = loss_fn(model(X[b]), y[b])
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), clip_norm)
            opt.step()
            total += loss.item() * len(b)
        history["train"].append(total / len(perm))
        if n_val:
            model.eval()
            with torch.no_grad():
                history["val"].append(loss_fn(model(X[val_idx]), y[val_idx]).item())
        if (epoch + 1) % max(1, epochs // 10) == 0:
            v = f"  val {history['val'][-1]:.4f}" if n_val else ""
            print(f"epoch {epoch + 1}/{epochs}  train {history['train'][-1]:.4f}{v}")
    model.cpu()
    return history


if __name__ == "__main__":
    MEMORY_NAME = "my_task_v1"
    CONTINUE_TRAINING = False          # True = keep refining the loaded weights

    X, y = ..., ...                    # the user's data
    database_init()
    model = create_mlp_with_sqlite_memory(input_dim=X.shape[-1], output_dim=3,
                                          hidden_layers=(64, 32), task="classification")
    memory_loaded = load_memory(model, MEMORY_NAME)

    if not memory_loaded or CONTINUE_TRAINING:
        if not memory_loaded:
            model.fit_scaler(X, y)     # only on a fresh model, see Gotchas
        train_mlp(model, X, y, lr=0.01 if not memory_loaded else 0.002)
        save_memory(model, MEMORY_NAME)
    else:
        print("memory loaded, skipping training")

    probs = model.predict(X)