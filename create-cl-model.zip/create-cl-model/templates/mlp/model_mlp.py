
import numpy as np
import torch
import torch.nn as nn

"""model_mlp.py -- MLP with SQLite memory support (He / Xavier-Glorot initialisation)."""


_ACTIVATIONS = {"relu": nn.ReLU, "leaky_relu": nn.LeakyReLU, "gelu": nn.GELU,
                "tanh": nn.Tanh, "sigmoid": nn.Sigmoid}
_HE_FRIENDLY = {"relu", "leaky_relu", "gelu"}      # 'auto' picks He for these, Xavier otherwise


class MLPWithMemory(nn.Module):
    def __init__(self, input_dim, hidden_layers, output_dim, task, activation,
                 dropout, init, seed, class_names=None):
        super().__init__()
        if seed is not None:
            torch.manual_seed(seed)
        self.task, self.activation_name = task, activation

        # config = STRUCTURE ONLY (what must match for saved weights to fit).
        self.config = {"architecture": "mlp", "task": task, "input_dim": input_dim,
                       "hidden_layers": list(hidden_layers), "output_dim": output_dim,
                       "activation": activation}
        if class_names is not None:
            self.config["class_names"] = list(class_names)

        layers, prev = [], input_dim
        for units in hidden_layers:
            # Dropout is ALWAYS present (p=0.0 means off) so parameter names never shift
            # when the user changes dropout between runs.
            layers += [nn.Linear(prev, units), _ACTIVATIONS[activation](), nn.Dropout(dropout)]
            prev = units
        layers.append(nn.Linear(prev, output_dim))   # no activation: logits / raw values
        self.net = nn.Sequential(*layers)

        # Scaler statistics live in buffers so they are saved and restored with the weights.
        self.register_buffer("x_mean", torch.zeros(input_dim))
        self.register_buffer("x_std", torch.ones(input_dim))
        self.register_buffer("y_mean", torch.zeros(output_dim))   # used by regression only
        self.register_buffer("y_std", torch.ones(output_dim))
        self._init_weights(init)

    def _init_weights(self, init):
        scheme = init if init != "auto" else ("he" if self.activation_name in _HE_FRIENDLY else "xavier")
        linears = [m for m in self.net if isinstance(m, nn.Linear)]
        for layer in linears[:-1]:                                  # hidden layers
            if scheme == "he":
                nl = "leaky_relu" if self.activation_name == "leaky_relu" else "relu"
                nn.init.kaiming_normal_(layer.weight, nonlinearity=nl)
            else:
                gain = nn.init.calculate_gain(self.activation_name) \
                    if self.activation_name in ("tanh", "relu", "leaky_relu") else 1.0
                nn.init.xavier_uniform_(layer.weight, gain=gain)
            nn.init.zeros_(layer.bias)
        nn.init.xavier_uniform_(linears[-1].weight)                 # linear output layer
        nn.init.zeros_(linears[-1].bias)

    @torch.no_grad()
    def fit_scaler(self, X, y=None):
        """Standardise inputs (and regression targets). Call ONLY on a fresh model,
        never after load_memory: the loaded weights were trained against the old statistics."""
        X = _as_2d(X, self.config["input_dim"])
        self.x_mean.copy_(X.mean(0))
        self.x_std.copy_(X.std(0, unbiased=False).clamp_min(1e-8))
        if self.task == "regression" and y is not None:
            y = _as_targets(y, self.config["output_dim"])
            self.y_mean.copy_(y.mean(0))
            self.y_std.copy_(y.std(0, unbiased=False).clamp_min(1e-8))

    def normalize_y(self, y):
        return (y - self.y_mean) / self.y_std

    def forward(self, x):                        # classification: logits; regression: normalised values
        return self.net((x - self.x_mean) / self.x_std)

    @torch.no_grad()
    def predict(self, X):
        """classification -> class probabilities; regression -> values in original units."""
        was_training = self.training
        self.eval()
        X = _as_2d(X, self.config["input_dim"]).to(self.x_mean.device)
        out = self(X)
        self.train(was_training)
        return torch.softmax(out, dim=1) if self.task == "classification" else out * self.y_std + self.y_mean


def _as_2d(X, input_dim):
    X = torch.as_tensor(np.asarray(X), dtype=torch.float32)
    if X.ndim == 1:
        X = X.unsqueeze(1)
    if X.ndim > 2:
        X = X.flatten(1)
    if X.shape[1] != input_dim:      # raise, never slice or pad
        raise ValueError(f"X has {X.shape[1]} features but the model expects input_dim={input_dim}")
    return X


def _as_targets(y, output_dim):
    y = torch.as_tensor(np.asarray(y), dtype=torch.float32)
    y = y.reshape(len(y), -1)
    if y.shape[1] != output_dim:
        raise ValueError(f"y has {y.shape[1]} columns but the model expects output_dim={output_dim}")
    return y


def create_mlp_with_sqlite_memory(input_dim, output_dim, hidden_layers=(64, 32),
                                  task="classification", activation="relu",
                                  dropout=0.0, init="auto", seed=42, class_names=None):
    """Build an MLP that satisfies the save_memory / load_memory contract (CPU, untrained)."""
    if task not in ("classification", "regression"):
        raise ValueError("task must be 'classification' or 'regression'")
    if activation not in _ACTIVATIONS:
        raise ValueError(f"activation must be one of {sorted(_ACTIVATIONS)}")
    if init not in ("auto", "he", "xavier"):
        raise ValueError("init must be 'auto', 'he' or 'xavier'")
    if input_dim < 1 or output_dim < 1 or any(h < 1 for h in hidden_layers):
        raise ValueError("all layer sizes must be positive integers")
    if task == "classification" and output_dim < 2:
        raise ValueError("classification needs output_dim >= 2 (one logit per class)")
    if class_names is not None and len(class_names) != output_dim:
        raise ValueError("class_names must have exactly output_dim entries")
    return MLPWithMemory(int(input_dim), [int(h) for h in hidden_layers], int(output_dim),
                         task, activation, float(dropout), init, seed, class_names)

