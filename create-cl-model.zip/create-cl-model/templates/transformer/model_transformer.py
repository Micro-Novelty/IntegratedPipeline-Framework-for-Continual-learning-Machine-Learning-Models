
import numpy as np
import torch
import torch.nn as nn

"""model_transformer.py -- plain PyTorch Transformer encoder with SQLite memory support."""


class TransformerWithMemory(nn.Module):
    def __init__(self, input_shape, output_dim, task, d_model, n_heads, n_layers,
                 dim_feedforward, ffn_activation, dropout, seed, class_names=None):
        super().__init__()
        if seed is not None:
            torch.manual_seed(seed)
        self.task = task
        # (F,)   -> every feature is one token of size 1      (tabular X, shape (N, F))
        # (T, F) -> T time steps with F features each          (windowed X, shape (N, T, F))
        self.features_as_tokens = len(input_shape) == 1
        self.seq_len, self.token_dim = (input_shape[0], 1) if self.features_as_tokens else tuple(input_shape)

        # config = STRUCTURE ONLY. n_heads and norm_first change no tensor shape but do change
        # what the weights mean, so they are structure and must match on load.
        self.config = {"architecture": "transformer", "task": task,
                       "input_shape": list(input_shape), "output_dim": output_dim,
                       "d_model": d_model, "n_heads": n_heads, "n_layers": n_layers,
                       "dim_feedforward": dim_feedforward, "ffn_activation": ffn_activation,
                       "norm_first": True}
        if class_names is not None:
            self.config["class_names"] = list(class_names)

        self.input_proj = nn.Linear(self.token_dim, d_model)
        self.pos_embedding = nn.Parameter(torch.zeros(1, self.seq_len, d_model))
        layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads, dim_feedforward=dim_feedforward, dropout=dropout,
            activation=ffn_activation, batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(layer, num_layers=n_layers, norm=nn.LayerNorm(d_model),
                                             enable_nested_tensor=False)
        self.head = nn.Linear(d_model, output_dim)

        # Scaler statistics live in buffers so they are saved and restored with the weights.
        stat_shape = (self.seq_len, 1) if self.features_as_tokens else (1, self.token_dim)
        self.register_buffer("x_mean", torch.zeros(stat_shape))
        self.register_buffer("x_std", torch.ones(stat_shape))
        self.register_buffer("y_mean", torch.zeros(output_dim))   # regression only
        self.register_buffer("y_std", torch.ones(output_dim))
        self._init_weights()

    def _init_weights(self):
        # Xavier/Glorot for every linear layer, small normal for positions, zero biases.
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        nn.init.trunc_normal_(self.pos_embedding, std=0.02)

    def prepare_inputs(self, X):
        """numpy / list / tensor -> float tensor (N, seq_len, token_dim). Raises on a shape mismatch."""
        X = torch.as_tensor(np.asarray(X), dtype=torch.float32)
        expected = tuple(self.config["input_shape"])
        if tuple(X.shape[1:]) != expected:
            raise ValueError(f"X has per-sample shape {tuple(X.shape[1:])} "
                             f"but the model expects {expected}")
        return X.unsqueeze(-1) if self.features_as_tokens else X

    def prepare_targets(self, y):
        """Regression targets -> float tensor (N, output_dim)."""
        y = torch.as_tensor(np.asarray(y), dtype=torch.float32)
        y = y.reshape(len(y), -1)
        if y.shape[1] != self.config["output_dim"]:
            raise ValueError(f"y has {y.shape[1]} columns but the model expects "
                             f"output_dim={self.config['output_dim']}")
        return y

    def normalize_y(self, y):
        return (y - self.y_mean) / self.y_std

    @torch.no_grad()
    def fit_scaler(self, X, y=None):
        """Standardise inputs (and regression targets). Call ONLY on a fresh model,
        never after load_memory: the loaded weights were trained against the old statistics."""
        tokens = self.prepare_inputs(X)                       # (N, T, token_dim)
        flat = tokens if self.features_as_tokens else tokens.reshape(-1, self.token_dim)
        mean, std = flat.mean(0), flat.std(0, unbiased=False).clamp_min(1e-8)
        if not self.features_as_tokens:
            mean, std = mean.unsqueeze(0), std.unsqueeze(0)   # (1, token_dim)
        self.x_mean.copy_(mean)
        self.x_std.copy_(std)
        if self.task == "regression" and y is not None:
            y = self.prepare_targets(y)
            self.y_mean.copy_(y.mean(0))
            self.y_std.copy_(y.std(0, unbiased=False).clamp_min(1e-8))

    def forward(self, tokens):                    # tokens: (N, seq_len, token_dim) from prepare_inputs
        x = (tokens - self.x_mean) / self.x_std
        x = self.input_proj(x) + self.pos_embedding
        x = self.encoder(x)
        return self.head(x.mean(dim=1))           # classification: logits; regression: normalised values

    @torch.no_grad()
    def predict(self, X):
        """classification -> class probabilities; regression -> values in original units."""
        was_training = self.training
        self.eval()
        out = self(self.prepare_inputs(X).to(self.x_mean.device))
        self.train(was_training)
        return torch.softmax(out, dim=1) if self.task == "classification" else out * self.y_std + self.y_mean


def create_transformer_with_sqlite_memory(input_shape, output_dim, task="classification",
                                          d_model=32, n_heads=4, n_layers=2,
                                          dim_feedforward=None, ffn_activation="gelu",
                                          dropout=0.1, seed=42, class_names=None):
    """Build a Transformer encoder that satisfies the save_memory / load_memory contract
    (CPU, untrained). Pass input_shape=X.shape[1:]: (F,) for tabular rows, (T, F) for windows."""
    input_shape = [int(s) for s in input_shape]
    if len(input_shape) not in (1, 2) or any(s < 1 for s in input_shape):
        raise ValueError("input_shape must be (F,) or (T, F) with positive sizes, i.e. X.shape[1:]")
    if task not in ("classification", "regression"):
        raise ValueError("task must be 'classification' or 'regression'")
    if d_model < 1 or n_heads < 1 or n_layers < 1 or output_dim < 1:
        raise ValueError("d_model, n_heads, n_layers and output_dim must be positive")
    if d_model % n_heads != 0:
        raise ValueError(f"d_model={d_model} must be divisible by n_heads={n_heads}")
    if ffn_activation not in ("gelu", "relu"):
        raise ValueError("ffn_activation must be 'gelu' or 'relu'")
    if task == "classification" and output_dim < 2:
        raise ValueError("classification needs output_dim >= 2 (one logit per class)")
    if class_names is not None and len(class_names) != output_dim:
        raise ValueError("class_names must have exactly output_dim entries")
    return TransformerWithMemory(input_shape, int(output_dim), task, int(d_model), int(n_heads),
                                 int(n_layers), int(dim_feedforward or 4 * d_model),
                                 ffn_activation, float(dropout), seed, class_names)

