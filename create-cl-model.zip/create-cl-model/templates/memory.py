"""SQLite weight memory for PyTorch models: database_init / save_memory / load_memory."""
import io
import json
import os
import sqlite3
from contextlib import closing

import torch

try:
    _HERE = os.path.dirname(os.path.abspath(__file__))
except NameError:                      # no __file__ (interactive session): fall back to the cwd
    _HERE = os.getcwd()
DB_PATH = os.path.join(_HERE, "activity_log.db")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS torch_weight_storage (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    memory_name TEXT    NOT NULL,
    model_type  TEXT    NOT NULL,              -- 'mlp' | 'transformer' | 'lstm'
    config      TEXT    NOT NULL,              -- JSON: structure the weights belong to
    weights     BLOB    NOT NULL,              -- torch.save(state_dict) bytes
    is_active   INTEGER NOT NULL DEFAULT 1,    -- 1 = current version, 0 = history
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_torch_weight_lookup
    ON torch_weight_storage (memory_name, model_type, is_active);
"""


class MemoryIncompatibleError(ValueError):
    """A memory with this name exists but does not fit the model being built."""


def database_init(db_path=DB_PATH):
    """Create the database file and weight table if missing. Safe to call every run."""
    with closing(sqlite3.connect(db_path)) as conn, conn:
        conn.executescript(_SCHEMA)


def _canonical(config):
    # JSON round-trip so tuples/lists and key order never cause false mismatches
    return json.loads(json.dumps(config, sort_keys=True))


def save_memory(model, memory_name, db_path=DB_PATH):
    """Persist weights under `memory_name`. Call ONCE, after training has finished.

    The previous active version is kept as history (is_active=0), never deleted.
    Returns the new row id.
    """
    state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
    broken = [k for k, v in state.items()
              if v.is_floating_point() and not bool(torch.isfinite(v).all())]
    if broken:
        raise ValueError(f"Refusing to save NaN/Inf weights (memory '{memory_name}'): {broken}")

    buf = io.BytesIO()
    torch.save(state, buf)
    config = _canonical(model.config)

    with closing(sqlite3.connect(db_path)) as conn, conn:   # one transaction
        conn.execute(
            "UPDATE torch_weight_storage SET is_active = 0 "
            "WHERE memory_name = ? AND model_type = ? AND is_active = 1",
            (memory_name, config["architecture"]))
        cur = conn.execute(
            "INSERT INTO torch_weight_storage (memory_name, model_type, config, weights, is_active) "
            "VALUES (?, ?, ?, ?, 1)",
            (memory_name, config["architecture"], json.dumps(config), sqlite3.Binary(buf.getvalue())))
        row_id = cur.lastrowid
    print(f"[memory] saved '{memory_name}' ({config['architecture']}) as row {row_id}")
    return row_id

def load_memory(model, memory_name, db_path=DB_PATH, version=None):
    """Load saved weights for `memory_name` into `model`.
 
    By default the active (newest) version is loaded. Pass `version` (a row id from
    list_memories()) to load a specific, possibly older version instead.
 
    Returns True if loaded, False if no memory exists yet (train, then save_memory).
    Raises MemoryIncompatibleError if a memory exists but does not match the model, and in
    that case the model is left completely untouched. Raises ValueError if an explicitly
    requested `version` does not exist for this memory name and architecture.
    """
    config = _canonical(model.config)
    sql = ("SELECT id, config, weights, created_at FROM torch_weight_storage "
           "WHERE memory_name = ? AND model_type = ? AND ")
    if version is None:
        sql += "is_active = 1 ORDER BY id DESC LIMIT 1"
        params = (memory_name, config["architecture"])
    else:
        sql += "id = ?"
        params = (memory_name, config["architecture"], int(version))
    with closing(sqlite3.connect(db_path)) as conn:
        row = conn.execute(sql, params).fetchone()
    if row is None:
        if version is not None:
            raise ValueError(f"No version {version} of '{memory_name}' ({config['architecture']}); "
                             f"see list_memories()")
        print(f"[memory] no saved '{config['architecture']}' memory named '{memory_name}'")
        return False
 
    row_id, saved_config, blob, created_at = row
    saved_config = json.loads(saved_config)
    if saved_config != config:
        raise MemoryIncompatibleError(
            f"Memory '{memory_name}' was saved with {saved_config}, but the model is {config}. "
            f"Use a different memory name or rebuild the model with the saved config.")
 
    state = torch.load(io.BytesIO(blob), map_location="cpu", weights_only=True)
    current = model.state_dict()
    if set(state) != set(current):
        raise MemoryIncompatibleError(f"Memory '{memory_name}': parameter names differ from the model.")
    for k, v in current.items():
        if tuple(state[k].shape) != tuple(v.shape):
            raise MemoryIncompatibleError(
                f"Memory '{memory_name}': '{k}' is {tuple(state[k].shape)}, model expects {tuple(v.shape)}.")
 
    model.load_state_dict(state, strict=True)   # every check passed, so this cannot half-apply
    model.memory_info = {"memory_name": memory_name, "row_id": row_id, "saved_at": created_at}
    print(f"[memory] loaded '{memory_name}' (row {row_id}, saved {created_at})")
    return True
 

def list_memories(memory_name=None, model_type=None, db_path=DB_PATH):
    """List saved versions, newest first, without loading any weights.
 
    Each item is a dict: id, memory_name, model_type, is_active, created_at, size_bytes, config.
    `id` is the number to pass as load_memory(..., version=id). Filter by `memory_name` and/or
    `model_type` ('mlp' | 'transformer' | 'lstm'). Returns [] when nothing is saved.
    Rolling back is: load_memory(model, name, version=<old id>) then save_memory(model, name),
    which stores the old weights as a NEW active version and keeps the full history.
    """
    if not os.path.exists(db_path):
        return []                                  # do not let sqlite create an empty file
    query = ("SELECT id, memory_name, model_type, is_active, created_at, LENGTH(weights), config "
             "FROM torch_weight_storage")
    clauses, params = [], []
    if memory_name is not None:
        clauses.append("memory_name = ?")
        params.append(memory_name)
    if model_type is not None:
        clauses.append("model_type = ?")
        params.append(model_type)
    if clauses:
        query += " WHERE " + " AND ".join(clauses)
    query += " ORDER BY id DESC"
    try:
        with closing(sqlite3.connect(db_path)) as conn:
            rows = conn.execute(query, params).fetchall()
    except sqlite3.OperationalError as e:
        if "no such table" in str(e):              # database file exists but database_init() never ran
            return []
        raise
    return [{"id": r[0], "memory_name": r[1], "model_type": r[2], "is_active": bool(r[3]),
             "created_at": r[4], "size_bytes": r[5], "config": json.loads(r[6])} for r in rows]
 