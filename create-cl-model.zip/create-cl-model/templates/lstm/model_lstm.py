"""model_lstm.py -- plain nn.LSTM with SQLite memory support."""
import numpy as np
import torch
import torch.nn as nn


class LSTMWithMemory(nn.Module):
    def __init__(self, input_size, output_dim, task, hidden_size, num_layers,
                 bidirectional, dropout, seed, class_names=None):
        super().__init__()
        if seed is not None:
            torch.manual_seed(seed)
        self.task = task

        # config = STRUCTURE ONLY. Sequence length is NOT structure: an LSTM accepts any length.
        self.config = {"architecture": "lstm", "task": task, "input_size": input_size,
                       "hidden_size": hidden_size, "num_layers": num_layers,
                       "bidirectional": bidirectional, "output_dim": output_dim}
        if class_names is not None:
            self.config["class_names"] = list(class_names)

        # nn.LSTM only applies dropout BETWEEN layers and warns when num_layers == 1,
        # so it is switched off there. self.drop is a separate dropout before the head;
        # it holds no parameters, so state_dict keys never depend on the dropout value.
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers=num_layers, batch_first=True,
                            bidirectional=bidirectional, dropout=dropout if num_layers > 1 else 0.0)
        self.drop = nn.Dropout(dropout)
        self.head = nn.Linear(hidden_size * (2 if bidirectional else 1), output_dim)

        # Scaler statistics live in buffers so they are saved and restored with the weights.
        self.register_buffer("x_mean", torch.zeros(input_size))
        self.register_buffer("x_std", torch.ones(input_size))
        self.register_buffer("y_mean", torch.zeros(output_dim))   # regression only
        self.register_buffer("y_std", torch.ones(output_dim))
        self._init_weights()

    def _init_weights(self):
        # Xavier/Glorot for input weights, orthogonal for recurrent weights, zero biases
        # except the forget gate (bias 1) so the cell remembers by default.
        h = self.lstm.hidden_size
        with torch.no_grad():
            for name, p in self.lstm.named_parameters():
                if name.startswith("weight_ih"):
                    nn.init.xavier_uniform_(p)
                elif name.startswith("weight_hh"):
                    nn.init.orthogonal_(p)
                else:                                    # bias_ih_*, bias_hh_*
                    nn.init.zeros_(p)
                    if name.startswith("bias_ih"):
                        p[h:2 * h] = 1.0                 # gate order is (input, forget, cell, output)
            nn.init.xavier_uniform_(self.head.weight)
            nn.init.zeros_(self.head.bias)

    def prepare_inputs(self, X):
        """numpy / list / tensor -> float tensor (N, T, input_size). Raises on a shape mismatch."""
        X = torch.as_tensor(np.asarray(X), dtype=torch.float32)
        size = self.config["input_size"]
        if X.ndim == 2:                                  # (N, T): univariate sequences
            if size != 1:
                raise ValueError(f"X is 2-D (N, T) but the model expects input_size={size}; "
                                 f"pass X as (N, T, {size})")
            X = X.unsqueeze(-1)
        if X.ndim != 3 or X.shape[-1] != size:
            raise ValueError(f"X must be (N, T, {size}) (or (N, T) when input_size=1), "
                             f"got {tuple(X.shape)}")
        return X

    def prepare_targets(self, y):
        """Regression targets -> float tensor (N, output_dim)."""
        y = torch.as_tensor(np.asarray(y), dtype=torch.float32)
        y = y.reshape(len(y), -1)
        if y.shape[1] != self.config["output_dim"]:
            raise ValueError(f"y has {y.shape[1]} columns but the model expects "
                             f"output_dim={self.config['output_dim']}")
        return y

    def normalize_y(self, y):
        return (y - self.y_mean) / self.y_std

    @torch.no_grad()
    def fit_scaler(self, X, y=None):
        """Standardise each feature across all samples and time steps (and regression targets).
        Call ONLY on a fresh model, never after load_memory: the loaded weights were trained
        against the old statistics."""
        flat = self.prepare_inputs(X).reshape(-1, self.config["input_size"])
        self.x_mean.copy_(flat.mean(0))
        self.x_std.copy_(flat.std(0, unbiased=False).clamp_min(1e-8))
        if self.task == "regression" and y is not None:
            y = self.prepare_targets(y)
            self.y_mean.copy_(y.mean(0))
            self.y_std.copy_(y.std(0, unbiased=False).clamp_min(1e-8))

    def forward(self, x):                       # x: (N, T, input_size) from prepare_inputs
        x = (x - self.x_mean) / self.x_std
        _, (h_n, _) = self.lstm(x)              # h_n: (num_layers * directions, N, hidden)
        last = torch.cat([h_n[-2], h_n[-1]], dim=1) if self.config["bidirectional"] else h_n[-1]
        return self.head(self.drop(last))       # classification: logits; regression: normalised values

    @torch.no_grad()
    def predict(self, X):
        """classification -> class probabilities; regression -> values in original units."""
        was_training = self.training
        self.eval()
        out = self(self.prepare_inputs(X).to(self.x_mean.device))
        self.train(was_training)
        return torch.softmax(out, dim=1) if self.task == "classification" else out * self.y_std + self.y_mean


def create_lstm_with_sqlite_memory(input_size, output_dim, task="classification",
                                   hidden_size=32, num_layers=1, bidirectional=False,
                                   dropout=0.1, seed=42, class_names=None):
    """Build an LSTM that satisfies the save_memory / load_memory contract (CPU, untrained).
    input_size = number of features per time step: X.shape[-1] for (N, T, F) data, 1 for (N, T)."""
    if task not in ("classification", "regression"):
        raise ValueError("task must be 'classification' or 'regression'")
    if input_size < 1 or output_dim < 1 or hidden_size < 1 or num_layers < 1:
        raise ValueError("input_size, output_dim, hidden_size and num_layers must be positive")
    if task == "classification" and output_dim < 2:
        raise ValueError("classification needs output_dim >= 2 (one logit per class)")
    if class_names is not None and len(class_names) != output_dim:
        raise ValueError("class_names must have exactly output_dim entries")
    return LSTMWithMemory(int(input_size), int(output_dim), task, int(hidden_size), int(num_layers),
                          bool(bidirectional), float(dropout), seed, class_names)