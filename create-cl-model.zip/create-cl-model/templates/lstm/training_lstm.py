"""train.py -- training loop and entry script for the LSTM."""
import numpy as np
import torch
import torch.nn as nn

from memory import database_init, load_memory, save_memory
from model_lstm import create_lstm_with_sqlite_memory


def train_lstm(model, X, y, epochs=50, lr=1e-3, weight_decay=0.0, batch_size=32, clip_norm=1.0,
               val_fraction=0.2, val_split="random", device="cpu", seed=42):
    """Standard supervised loop. Returns {'train': [...], 'val': [...]} loss history.

    val_split="random": independent sequences (e.g. activity classification).
    val_split="tail":   the last val_fraction of samples, for windows cut from ONE time series,
                        where a random split would leak overlapping windows into validation.
    """
    cfg = model.config
    X = model.prepare_inputs(X)
    if cfg["task"] == "classification":
        y = torch.as_tensor(np.asarray(y))
        if y.ndim == 2 and y.shape[1] == cfg["output_dim"]:
            y = y.argmax(1)                              # accept one-hot
        y = y.reshape(-1).long()
        if len(y) and (y.min() < 0 or y.max() >= cfg["output_dim"]):
            raise ValueError(f"labels span {int(y.min())}..{int(y.max())}, "
                             f"but output_dim={cfg['output_dim']}")
        loss_fn = nn.CrossEntropyLoss()
    else:
        y = model.normalize_y(model.prepare_targets(y).to(model.y_mean.device))  # normalised space
        loss_fn = nn.MSELoss()
    if len(X) != len(y):
        raise ValueError(f"X has {len(X)} samples but y has {len(y)}")
    if val_split not in ("random", "tail"):
        raise ValueError("val_split must be 'random' or 'tail'")

    g = torch.Generator().manual_seed(seed)
    n_val = int(len(X) * val_fraction) if len(X) >= 4 else 0   # too few samples: no validation
    if val_split == "tail":
        order = torch.arange(len(X))
        tr_idx, val_idx = order[:len(X) - n_val], order[len(X) - n_val:]
    else:
        order = torch.randperm(len(X), generator=g)
        val_idx, tr_idx = order[:n_val], order[n_val:]

    model.to(device)
    X, y = X.to(device), y.to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)  # fresh every run
    history = {"train": [], "val": []}
    for epoch in range(epochs):
        model.train()
        perm = tr_idx[torch.randperm(len(tr_idx), generator=g)]
        total = 0.0
        for i in range(0, len(perm), batch_size):
            b = perm[i:i + batch_size]
            opt.zero_grad()
            loss = loss_fn(model(X[b]), y[b])
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), clip_norm)   # recurrent nets: keep this
            opt.step()
            total += loss.item() * len(b)
        history["train"].append(total / len(perm))
        if n_val:
            model.eval()
            with torch.no_grad():
                history["val"].append(loss_fn(model(X[val_idx]), y[val_idx]).item())
        if (epoch + 1) % max(1, epochs // 10) == 0:
            v = f"  val {history['val'][-1]:.4f}" if n_val else ""
            print(f"epoch {epoch + 1}/{epochs}  train {history['train'][-1]:.4f}{v}")
    model.cpu()
    return history


if __name__ == "__main__":
    MEMORY_NAME = "my_task_v1"
    CONTINUE_TRAINING = False          # True = keep refining the loaded weights

    X, y = ..., ...                    # the user's data: X (N, T, F), or (N, T) for one feature
    database_init()
    model = create_lstm_with_sqlite_memory(input_size=X.shape[-1] if X.ndim == 3 else 1,
                                           output_dim=3, task="classification")
    memory_loaded = load_memory(model, MEMORY_NAME)

    if not memory_loaded or CONTINUE_TRAINING:
        if not memory_loaded:
            model.fit_scaler(X, y)     # only on a fresh model, see Gotchas
        train_lstm(model, X, y, lr=1e-3 if not memory_loaded else 2e-4)
        save_memory(model, MEMORY_NAME)
    else:
        print("memory loaded, skipping training")

    probs = model.predict(X)