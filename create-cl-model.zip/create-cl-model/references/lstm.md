# LSTM reference: `create_lstm_with_sqlite_memory()`

Read this when the user's data is ordered sequences (sensor windows, time series, activity
signals) and they want an LSTM for classification or regression. It is a **plain `nn.LSTM`**
with a linear head, bundled with `save_memory` / `load_memory` from `SKILL.md`. It provides
the model template for `model.py`, the training loop and entry script for `train.py`, and a
smoke test.

Contents: what this is and is not, contract, input shapes, model.py, train.py, choosing
parameters, initialisation, when to prefer another architecture, gotchas, verify.

## What this is, and what it is not

Standard PyTorch, deliberately. Compared with the LSTM in AbstractIntegratedModule:

- the recurrence is `nn.LSTM` (cuDNN-accelerated on GPU), not a hand-written cell with
  concatenated gate matrices.
- there is no `LSTMEngine` confidence/calibration layer. The framework saves
  `residual_mean`, `residual_std` and quantiles beside its LSTM weights to express
  uncertainty; this version stores weights and scaler statistics only. If the user wants
  prediction intervals, that is a separate feature to build on request (for example residual
  quantiles from a validation set kept in buffers), not something to add unasked.
- it is a standalone model, not the framework's short-term-memory support for an ensemble.

Weights saved by this model are **not** interchangeable with the NumPy framework's LSTM
weights. The structures differ, and they live in a separate table anyway.

## Contract

Returns an untrained CPU `nn.Module` whose `config` holds structure only:

| key | meaning |
|---|---|
| `architecture` | always `"lstm"` |
| `task` | `"classification"` or `"regression"` |
| `input_size` | features per time step |
| `hidden_size`, `num_layers`, `bidirectional` | recurrent stack |
| `output_dim` | classes (classification) or targets/horizon (regression) |
| `class_names` | ordered labels, only if the user supplies them |

Not in `config`: **sequence length**, dropout, learning rate, epochs, seed. An LSTM has no
positional embedding, so a memory trained on 30-step windows can run on other lengths
without a structural mismatch (accuracy at a very different length is for the user to judge).

## Input shapes

| `X` shape | meaning | `input_size` |
|---|---|---|
| `(N, T, F)` | N sequences of T steps with F features each | `F` (`X.shape[-1]`) |
| `(N, T)` | N univariate sequences | `1` |

Always `batch_first`. A 2-D `X` is read as univariate sequences, never as N samples of one
step. Pass `input_size = X.shape[-1] if X.ndim == 3 else 1`.

The model reads the whole sequence and predicts from the **final hidden state**, giving one
output per sequence (a class, or `output_dim` values such as a forecast horizon). Per-step
outputs (sequence-to-sequence) are outside this template.

## model.py

```python
"""model.py -- plain nn.LSTM with SQLite memory support."""
import numpy as np
import torch
import torch.nn as nn


class LSTMWithMemory(nn.Module):
    def __init__(self, input_size, output_dim, task, hidden_size, num_layers,
                 bidirectional, dropout, seed, class_names=None):
        super().__init__()
        if seed is not None:
            torch.manual_seed(seed)
        self.task = task

        # config = STRUCTURE ONLY. Sequence length is NOT structure: an LSTM accepts any length.
        self.config = {"architecture": "lstm", "task": task, "input_size": input_size,
                       "hidden_size": hidden_size, "num_layers": num_layers,
                       "bidirectional": bidirectional, "output_dim": output_dim}
        if class_names is not None:
            self.config["class_names"] = list(class_names)

        # nn.LSTM only applies dropout BETWEEN layers and warns when num_layers == 1,
        # so it is switched off there. self.drop is a separate dropout before the head;
        # it holds no parameters, so state_dict keys never depend on the dropout value.
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers=num_layers, batch_first=True,
                            bidirectional=bidirectional, dropout=dropout if num_layers > 1 else 0.0)
        self.drop = nn.Dropout(dropout)
        self.head = nn.Linear(hidden_size * (2 if bidirectional else 1), output_dim)

        # Scaler statistics live in buffers so they are saved and restored with the weights.
        self.register_buffer("x_mean", torch.zeros(input_size))
        self.register_buffer("x_std", torch.ones(input_size))
        self.register_buffer("y_mean", torch.zeros(output_dim))   # regression only
        self.register_buffer("y_std", torch.ones(output_dim))
        self._init_weights()

    def _init_weights(self):
        # Xavier/Glorot for input weights, orthogonal for recurrent weights, zero biases
        # except the forget gate (bias 1) so the cell remembers by default.
        h = self.lstm.hidden_size
        with torch.no_grad():
            for name, p in self.lstm.named_parameters():
                if name.startswith("weight_ih"):
                    nn.init.xavier_uniform_(p)
                elif name.startswith("weight_hh"):
                    nn.init.orthogonal_(p)
                else:                                    # bias_ih_*, bias_hh_*
                    nn.init.zeros_(p)
                    if name.startswith("bias_ih"):
                        p[h:2 * h] = 1.0                 # gate order is (input, forget, cell, output)
            nn.init.xavier_uniform_(self.head.weight)
            nn.init.zeros_(self.head.bias)

    def prepare_inputs(self, X):
        """numpy / list / tensor -> float tensor (N, T, input_size). Raises on a shape mismatch."""
        X = torch.as_tensor(np.asarray(X), dtype=torch.float32)
        size = self.config["input_size"]
        if X.ndim == 2:                                  # (N, T): univariate sequences
            if size != 1:
                raise ValueError(f"X is 2-D (N, T) but the model expects input_size={size}; "
                                 f"pass X as (N, T, {size})")
            X = X.unsqueeze(-1)
        if X.ndim != 3 or X.shape[-1] != size:
            raise ValueError(f"X must be (N, T, {size}) (or (N, T) when input_size=1), "
                             f"got {tuple(X.shape)}")
        return X

    def prepare_targets(self, y):
        """Regression targets -> float tensor (N, output_dim)."""
        y = torch.as_tensor(np.asarray(y), dtype=torch.float32)
        y = y.reshape(len(y), -1)
        if y.shape[1] != self.config["output_dim"]:
            raise ValueError(f"y has {y.shape[1]} columns but the model expects "
                             f"output_dim={self.config['output_dim']}")
        return y

    def normalize_y(self, y):
        return (y - self.y_mean) / self.y_std

    @torch.no_grad()
    def fit_scaler(self, X, y=None):
        """Standardise each feature across all samples and time steps (and regression targets).
        Call ONLY on a fresh model, never after load_memory: the loaded weights were trained
        against the old statistics."""
        flat = self.prepare_inputs(X).reshape(-1, self.config["input_size"])
        self.x_mean.copy_(flat.mean(0))
        self.x_std.copy_(flat.std(0, unbiased=False).clamp_min(1e-8))
        if self.task == "regression" and y is not None:
            y = self.prepare_targets(y)
            self.y_mean.copy_(y.mean(0))
            self.y_std.copy_(y.std(0, unbiased=False).clamp_min(1e-8))

    def forward(self, x):                       # x: (N, T, input_size) from prepare_inputs
        x = (x - self.x_mean) / self.x_std
        _, (h_n, _) = self.lstm(x)              # h_n: (num_layers * directions, N, hidden)
        last = torch.cat([h_n[-2], h_n[-1]], dim=1) if self.config["bidirectional"] else h_n[-1]
        return self.head(self.drop(last))       # classification: logits; regression: normalised values

    @torch.no_grad()
    def predict(self, X):
        """classification -> class probabilities; regression -> values in original units."""
        was_training = self.training
        self.eval()
        out = self(self.prepare_inputs(X).to(self.x_mean.device))
        self.train(was_training)
        return torch.softmax(out, dim=1) if self.task == "classification" else out * self.y_std + self.y_mean


def create_lstm_with_sqlite_memory(input_size, output_dim, task="classification",
                                   hidden_size=32, num_layers=1, bidirectional=False,
                                   dropout=0.1, seed=42, class_names=None):
    """Build an LSTM that satisfies the save_memory / load_memory contract (CPU, untrained).
    input_size = number of features per time step: X.shape[-1] for (N, T, F) data, 1 for (N, T)."""
    if task not in ("classification", "regression"):
        raise ValueError("task must be 'classification' or 'regression'")
    if input_size < 1 or output_dim < 1 or hidden_size < 1 or num_layers < 1:
        raise ValueError("input_size, output_dim, hidden_size and num_layers must be positive")
    if task == "classification" and output_dim < 2:
        raise ValueError("classification needs output_dim >= 2 (one logit per class)")
    if class_names is not None and len(class_names) != output_dim:
        raise ValueError("class_names must have exactly output_dim entries")
    return LSTMWithMemory(int(input_size), int(output_dim), task, int(hidden_size), int(num_layers),
                          bool(bidirectional), float(dropout), seed, class_names)
```

## train.py

Adapt the `__main__` block to the user's data. `X, y = ..., ...` is a placeholder, not
runnable as written.

```python
"""train.py -- training loop and entry script for the LSTM."""
import numpy as np
import torch
import torch.nn as nn

from memory import database_init, load_memory, save_memory
from model import create_lstm_with_sqlite_memory


def train_lstm(model, X, y, epochs=50, lr=1e-3, weight_decay=0.0, batch_size=32, clip_norm=1.0,
               val_fraction=0.2, val_split="random", device="cpu", seed=42):
    """Standard supervised loop. Returns {'train': [...], 'val': [...]} loss history.

    val_split="random": independent sequences (e.g. activity classification).
    val_split="tail":   the last val_fraction of samples, for windows cut from ONE time series,
                        where a random split would leak overlapping windows into validation.
    """
    cfg = model.config
    X = model.prepare_inputs(X)
    if cfg["task"] == "classification":
        y = torch.as_tensor(np.asarray(y))
        if y.ndim == 2 and y.shape[1] == cfg["output_dim"]:
            y = y.argmax(1)                              # accept one-hot
        y = y.reshape(-1).long()
        if len(y) and (y.min() < 0 or y.max() >= cfg["output_dim"]):
            raise ValueError(f"labels span {int(y.min())}..{int(y.max())}, "
                             f"but output_dim={cfg['output_dim']}")
        loss_fn = nn.CrossEntropyLoss()
    else:
        y = model.normalize_y(model.prepare_targets(y).to(model.y_mean.device))  # normalised space
        loss_fn = nn.MSELoss()
    if len(X) != len(y):
        raise ValueError(f"X has {len(X)} samples but y has {len(y)}")
    if val_split not in ("random", "tail"):
        raise ValueError("val_split must be 'random' or 'tail'")

    g = torch.Generator().manual_seed(seed)
    n_val = int(len(X) * val_fraction) if len(X) >= 4 else 0   # too few samples: no validation
    if val_split == "tail":
        order = torch.arange(len(X))
        tr_idx, val_idx = order[:len(X) - n_val], order[len(X) - n_val:]
    else:
        order = torch.randperm(len(X), generator=g)
        val_idx, tr_idx = order[:n_val], order[n_val:]

    model.to(device)
    X, y = X.to(device), y.to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)  # fresh every run
    history = {"train": [], "val": []}
    for epoch in range(epochs):
        model.train()
        perm = tr_idx[torch.randperm(len(tr_idx), generator=g)]
        total = 0.0
        for i in range(0, len(perm), batch_size):
            b = perm[i:i + batch_size]
            opt.zero_grad()
            loss = loss_fn(model(X[b]), y[b])
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), clip_norm)   # recurrent nets: keep this
            opt.step()
            total += loss.item() * len(b)
        history["train"].append(total / len(perm))
        if n_val:
            model.eval()
            with torch.no_grad():
                history["val"].append(loss_fn(model(X[val_idx]), y[val_idx]).item())
        if (epoch + 1) % max(1, epochs // 10) == 0:
            v = f"  val {history['val'][-1]:.4f}" if n_val else ""
            print(f"epoch {epoch + 1}/{epochs}  train {history['train'][-1]:.4f}{v}")
    model.cpu()
    return history


if __name__ == "__main__":
    MEMORY_NAME = "my_task_v1"
    CONTINUE_TRAINING = False          # True = keep refining the loaded weights

    X, y = ..., ...                    # the user's data: X (N, T, F), or (N, T) for one feature
    database_init()
    model = create_lstm_with_sqlite_memory(input_size=X.shape[-1] if X.ndim == 3 else 1,
                                           output_dim=3, task="classification")
    memory_loaded = load_memory(model, MEMORY_NAME)

    if not memory_loaded or CONTINUE_TRAINING:
        if not memory_loaded:
            model.fit_scaler(X, y)     # only on a fresh model, see Gotchas
        train_lstm(model, X, y, lr=1e-3 if not memory_loaded else 2e-4)
        save_memory(model, MEMORY_NAME)
    else:
        print("memory loaded, skipping training")

    probs = model.predict(X)
```

Defaults: Adam, learning rate 1e-3, gradient-norm clipping at 1.0, 50 epochs. When
continuing from loaded weights the template drops the learning rate to 2e-4 so the refined
weights are adjusted rather than overwritten.

## Choosing parameters

- **`hidden_size`**: 32 by default, matching the framework's small setup. Try 64 to 128 for
  larger datasets or richer signals; keep it small for edge targets.
- **`num_layers`**: 1 unless the user has a lot of data. Two layers is the usual next step.
- **`bidirectional`**: off by default. It is reasonable for classifying a complete recorded
  window, but do not use it where the model must only look backward in time.
- **`dropout`**: applies between layers (when `num_layers > 1`) and before the head.
- **`output_dim`**: number of classes, or number of regression targets.
- **`class_names`**: pass whenever the user has labels. It is saved in `config`, so a memory
  trained with another class order refuses to load instead of mislabelling.
- **`val_split`**: choose it for the user. Use `"tail"` when the windows are cut from one
  time series (the usual regression case): consecutive windows overlap, so a random split
  leaks training data into validation and the validation loss looks better than it is. Use
  `"random"` for independent sequences, such as separate recordings to classify.

## Initialisation

Xavier/Glorot uniform for the input weights, orthogonal for the recurrent weights, zero
biases except the forget gate (set to 1 so the cell remembers by default), and Xavier for
the head. These are standard recurrent-network choices and keep the Xavier/Glorot approach
used elsewhere in this skill. Initialisation only matters for a fresh model; a successful
`load_memory` overwrites it, which is why it stays out of `config`.

## When to prefer another architecture

Say this in one sentence when it applies, then still build what was asked:

- **Independent tabular rows** with no real order: an MLP is simpler and usually as good.
- **Long sequences** (hundreds of steps): LSTMs train slowly because steps run one after
  another, and they struggle to keep very old context, as the framework's README notes. Try
  shorter windows or a Transformer.
- **Very small datasets**: a small `hidden_size` and clipping help, but expect noisy
  validation.

## Gotchas

- **Orientation.** `X` is `(N, T, F)` with the batch first. Do not feed `(T, N, F)`.
- **No padding or masking.** Every sequence in `X` has the same length. Ragged data needs
  `pack_padded_sequence`, which this template does not include; ask the user to pad or crop,
  or tell them it is outside the template.
- **Structure keys.** `hidden_size`, `num_layers`, `bidirectional` and `input_size` must match
  on load. The `verify_lstm.py` script tests each one.
- **Dropout.** `nn.LSTM` warns if given dropout with one layer, so the template turns the
  between-layer dropout off there. The separate dropout before the head has no parameters, so
  `state_dict` keys never depend on the dropout value.
- **Fit the scaler once.** `x_mean` / `x_std` (per feature, across all samples and steps) and
  `y_mean` / `y_std` for regression are buffers saved with the weights. Call `fit_scaler` only
  when `load_memory` returned `False`. New data with a different range is a new task and
  deserves a new memory name.
- **Keep gradient clipping.** Recurrent networks can have exploding gradients. If the loss
  goes NaN anyway, lower the learning rate. `save_memory` refuses NaN or Inf weights, so a
  diverged run cannot overwrite a good memory.
- **Logits out, no softmax inside the model.** `CrossEntropyLoss` applies softmax itself;
  softmax happens only in `predict()`. Labels are class indices (one-hot is accepted by
  `train_lstm` and converted).
- **Regression trains in normalised space**; `predict()` converts back to original units.
- **Device.** Build, load, then `.to(device)` (done inside `train_lstm`). The optimizer is
  created fresh each run, after the load.
- **Small data.** Under 4 samples there is no validation split. The loop keeps the final
  weights, with no early stopping.

## Verify

Save as `verify_lstm.py` next to the other files and run it. It covers the checklist in
`SKILL.md` plus scaler persistence, both input shapes, changed sequence length, each
structural mismatch, and original-unit regression output.

```python
"""Smoke test for the LSTM memory. Run from the folder containing memory.py, model.py, train.py."""
import os
import sqlite3

import numpy as np
import torch

from memory import database_init, save_memory, load_memory, MemoryIncompatibleError
from model import create_lstm_with_sqlite_memory
from train import train_lstm

DB = "verify_lstm.db"
if os.path.exists(DB):
    os.remove(DB)
database_init(DB)


def same_weights(a, b):
    return all(torch.equal(x, y) for x, y in zip(a.state_dict().values(), b.state_dict().values()))


def must_raise(model, name):
    before = {k: v.clone() for k, v in model.state_dict().items()}
    try:
        load_memory(model, name, DB)
        raise AssertionError("expected MemoryIncompatibleError")
    except MemoryIncompatibleError:
        pass
    assert all(torch.equal(before[k], v) for k, v in model.state_dict().items())


# classification on sequences (N, T, F), two layers so between-layer dropout is active
X = np.random.randn(64, 12, 3).astype("float32")
y = np.random.randint(0, 3, 64)
m1 = create_lstm_with_sqlite_memory(3, 3, hidden_size=8, num_layers=2, dropout=0.3)
m1.fit_scaler(X)
train_lstm(m1, X, y, epochs=2)
save_memory(m1, "verify", DB)

# a different seed and dropout must NOT block loading (they are not structure)
m2 = create_lstm_with_sqlite_memory(3, 3, hidden_size=8, num_layers=2, dropout=0.0, seed=7)
assert load_memory(m2, "verify", DB) is True
assert same_weights(m1, m2)                                   # includes scaler buffers
assert torch.allclose(m1.predict(X), m2.predict(X), atol=1e-6)

# sequence length is not structure: a longer window still predicts
assert m2.predict(np.random.randn(5, 30, 3).astype("float32")).shape == (5, 3)

# structural differences must raise and leave the model untouched
must_raise(create_lstm_with_sqlite_memory(3, 3, hidden_size=16, num_layers=2), "verify")
must_raise(create_lstm_with_sqlite_memory(3, 3, hidden_size=8, num_layers=1), "verify")
must_raise(create_lstm_with_sqlite_memory(3, 3, hidden_size=8, num_layers=2, bidirectional=True), "verify")

# versioning: second save keeps history, exactly one active row
save_memory(m1, "verify", DB)
rows = sqlite3.connect(DB).execute(
    "SELECT is_active FROM torch_weight_storage WHERE memory_name='verify' ORDER BY id").fetchall()
assert rows == [(0,), (1,)], rows

# univariate regression on (N, T) windows with a tail split: original-unit predictions
Xu = np.random.randn(60, 10).astype("float32")
yu = (Xu.mean(axis=1) * 40 + 500).reshape(-1, 1)
mu = create_lstm_with_sqlite_memory(1, 1, task="regression", hidden_size=8)
mu.fit_scaler(Xu, yu)
train_lstm(mu, Xu, yu, epochs=2, val_split="tail")
save_memory(mu, "verify_uni", DB)
mu2 = create_lstm_with_sqlite_memory(1, 1, task="regression", hidden_size=8)
assert load_memory(mu2, "verify_uni", DB) is True
assert mu2.predict(Xu).mean().item() > 100, "regression output should be in original units"
assert torch.allclose(mu.predict(Xu), mu2.predict(Xu), atol=1e-4)

# wrong feature count raises instead of being sliced or padded
try:
    m1.predict(np.random.randn(4, 12, 5).astype("float32"))
    raise AssertionError("expected ValueError")
except ValueError:
    pass

os.remove(DB)
print("LSTM memory checks passed")
```

Run it when a Python environment with torch is available. If not, say the checks were not
run. Note: the LSTM code in this reference was syntax-checked but not executed against real
PyTorch when this skill was drafted, so the first real run of `verify_lstm.py` is also the
first test of the template itself.
