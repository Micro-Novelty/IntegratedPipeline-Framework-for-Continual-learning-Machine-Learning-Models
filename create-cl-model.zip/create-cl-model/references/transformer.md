# Transformer reference: `create_transformer_with_sqlite_memory()`

Read this when the user wants a Transformer on numeric `X` / `y` samples, for classification
or regression. It is a **regular PyTorch Transformer encoder** (`nn.TransformerEncoder`),
bundled with `save_memory` / `load_memory` from `SKILL.md`. It provides the model template
for `model.py`, the training loop and entry script for `train.py`, and a smoke test.

Contents: what this is and is not, contract, input shapes, model.py, train.py, choosing
parameters, initialisation, when to prefer another architecture, gotchas, verify.

## What this is, and what it is not

Plain on purpose, so anyone can read, modify and deploy it without learning the framework's
internals. Compared with the Transformer in AbstractIntegratedModule, this version has:

- **one ordinary backward pass.** No `fixed_backward` / `dynamic_backward` modes.
- **no alpha blend** of fixed and learned attention, and no frozen `W_q_fixed` / `W_k_fixed` /
  `W_v_fixed` copies. Attention is the standard learned multi-head attention.
- **no token indices.** No vocabulary, no `input_ids`, no `nn.Embedding`. The model takes
  numeric `X` and `y` only.
- none of the kNN/HNSW memory or attention-quality bookkeeping.

Consequence worth telling the user if they mention the NumPy framework: weights saved by this
model are **not** interchangeable with that framework's Transformer weights. The structures
differ, and they live in a separate table anyway.

## Contract

Returns an untrained CPU `nn.Module` whose `config` holds structure only:

| key | meaning |
|---|---|
| `architecture` | always `"transformer"` |
| `task` | `"classification"` or `"regression"` |
| `input_shape` | `X.shape[1:]`: `[F]` for tabular rows, `[T, F]` for windows |
| `output_dim` | classes (classification) or targets/horizon (regression) |
| `d_model`, `n_heads`, `n_layers` | encoder size |
| `dim_feedforward`, `ffn_activation` | feed-forward block (`gelu` or `relu`) |
| `norm_first` | always `true` (pre-LayerNorm) |
| `class_names` | ordered labels, only if the user supplies them |

Not in `config`: dropout, weight decay, seed, learning rate, epochs. The user can change
those between runs and still load the same memory.

## Input shapes

The model never sees token ids, only numbers, so `X` decides how tokens are formed:

| `X` shape | tokens | `input_shape` |
|---|---|---|
| `(N, F)` tabular rows | each feature is one token, sequence length `F` | `(F,)` |
| `(N, T, F)` windows or time series | each time step is one token with `F` features | `(T, F)` |

Both go through the same encoder: a linear projection to `d_model`, a learned positional
embedding, the encoder stack, mean pooling over tokens, then a linear head. Callers pass
`input_shape=X.shape[1:]` and the right mode is picked automatically.

## model.py

```python
"""model.py -- plain PyTorch Transformer encoder with SQLite memory support."""
import numpy as np
import torch
import torch.nn as nn


class TransformerWithMemory(nn.Module):
    def __init__(self, input_shape, output_dim, task, d_model, n_heads, n_layers,
                 dim_feedforward, ffn_activation, dropout, seed, class_names=None):
        super().__init__()
        if seed is not None:
            torch.manual_seed(seed)
        self.task = task
        # (F,)   -> every feature is one token of size 1      (tabular X, shape (N, F))
        # (T, F) -> T time steps with F features each          (windowed X, shape (N, T, F))
        self.features_as_tokens = len(input_shape) == 1
        self.seq_len, self.token_dim = (input_shape[0], 1) if self.features_as_tokens else tuple(input_shape)

        # config = STRUCTURE ONLY. n_heads and norm_first change no tensor shape but do change
        # what the weights mean, so they are structure and must match on load.
        self.config = {"architecture": "transformer", "task": task,
                       "input_shape": list(input_shape), "output_dim": output_dim,
                       "d_model": d_model, "n_heads": n_heads, "n_layers": n_layers,
                       "dim_feedforward": dim_feedforward, "ffn_activation": ffn_activation,
                       "norm_first": True}
        if class_names is not None:
            self.config["class_names"] = list(class_names)

        self.input_proj = nn.Linear(self.token_dim, d_model)
        self.pos_embedding = nn.Parameter(torch.zeros(1, self.seq_len, d_model))
        layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads, dim_feedforward=dim_feedforward, dropout=dropout,
            activation=ffn_activation, batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(layer, num_layers=n_layers, norm=nn.LayerNorm(d_model),
                                             enable_nested_tensor=False)
        self.head = nn.Linear(d_model, output_dim)

        # Scaler statistics live in buffers so they are saved and restored with the weights.
        stat_shape = (self.seq_len, 1) if self.features_as_tokens else (1, self.token_dim)
        self.register_buffer("x_mean", torch.zeros(stat_shape))
        self.register_buffer("x_std", torch.ones(stat_shape))
        self.register_buffer("y_mean", torch.zeros(output_dim))   # regression only
        self.register_buffer("y_std", torch.ones(output_dim))
        self._init_weights()

    def _init_weights(self):
        # Xavier/Glorot for every linear layer, small normal for positions, zero biases.
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        nn.init.trunc_normal_(self.pos_embedding, std=0.02)

    def prepare_inputs(self, X):
        """numpy / list / tensor -> float tensor (N, seq_len, token_dim). Raises on a shape mismatch."""
        X = torch.as_tensor(np.asarray(X), dtype=torch.float32)
        expected = tuple(self.config["input_shape"])
        if tuple(X.shape[1:]) != expected:
            raise ValueError(f"X has per-sample shape {tuple(X.shape[1:])} "
                             f"but the model expects {expected}")
        return X.unsqueeze(-1) if self.features_as_tokens else X

    def prepare_targets(self, y):
        """Regression targets -> float tensor (N, output_dim)."""
        y = torch.as_tensor(np.asarray(y), dtype=torch.float32)
        y = y.reshape(len(y), -1)
        if y.shape[1] != self.config["output_dim"]:
            raise ValueError(f"y has {y.shape[1]} columns but the model expects "
                             f"output_dim={self.config['output_dim']}")
        return y

    def normalize_y(self, y):
        return (y - self.y_mean) / self.y_std

    @torch.no_grad()
    def fit_scaler(self, X, y=None):
        """Standardise inputs (and regression targets). Call ONLY on a fresh model,
        never after load_memory: the loaded weights were trained against the old statistics."""
        tokens = self.prepare_inputs(X)                       # (N, T, token_dim)
        flat = tokens if self.features_as_tokens else tokens.reshape(-1, self.token_dim)
        mean, std = flat.mean(0), flat.std(0, unbiased=False).clamp_min(1e-8)
        if not self.features_as_tokens:
            mean, std = mean.unsqueeze(0), std.unsqueeze(0)   # (1, token_dim)
        self.x_mean.copy_(mean)
        self.x_std.copy_(std)
        if self.task == "regression" and y is not None:
            y = self.prepare_targets(y)
            self.y_mean.copy_(y.mean(0))
            self.y_std.copy_(y.std(0, unbiased=False).clamp_min(1e-8))

    def forward(self, tokens):                    # tokens: (N, seq_len, token_dim) from prepare_inputs
        x = (tokens - self.x_mean) / self.x_std
        x = self.input_proj(x) + self.pos_embedding
        x = self.encoder(x)
        return self.head(x.mean(dim=1))           # classification: logits; regression: normalised values

    @torch.no_grad()
    def predict(self, X):
        """classification -> class probabilities; regression -> values in original units."""
        was_training = self.training
        self.eval()
        out = self(self.prepare_inputs(X).to(self.x_mean.device))
        self.train(was_training)
        return torch.softmax(out, dim=1) if self.task == "classification" else out * self.y_std + self.y_mean


def create_transformer_with_sqlite_memory(input_shape, output_dim, task="classification",
                                          d_model=32, n_heads=4, n_layers=2,
                                          dim_feedforward=None, ffn_activation="gelu",
                                          dropout=0.1, seed=42, class_names=None):
    """Build a Transformer encoder that satisfies the save_memory / load_memory contract
    (CPU, untrained). Pass input_shape=X.shape[1:]: (F,) for tabular rows, (T, F) for windows."""
    input_shape = [int(s) for s in input_shape]
    if len(input_shape) not in (1, 2) or any(s < 1 for s in input_shape):
        raise ValueError("input_shape must be (F,) or (T, F) with positive sizes, i.e. X.shape[1:]")
    if task not in ("classification", "regression"):
        raise ValueError("task must be 'classification' or 'regression'")
    if d_model < 1 or n_heads < 1 or n_layers < 1 or output_dim < 1:
        raise ValueError("d_model, n_heads, n_layers and output_dim must be positive")
    if d_model % n_heads != 0:
        raise ValueError(f"d_model={d_model} must be divisible by n_heads={n_heads}")
    if ffn_activation not in ("gelu", "relu"):
        raise ValueError("ffn_activation must be 'gelu' or 'relu'")
    if task == "classification" and output_dim < 2:
        raise ValueError("classification needs output_dim >= 2 (one logit per class)")
    if class_names is not None and len(class_names) != output_dim:
        raise ValueError("class_names must have exactly output_dim entries")
    return TransformerWithMemory(input_shape, int(output_dim), task, int(d_model), int(n_heads),
                                 int(n_layers), int(dim_feedforward or 4 * d_model),
                                 ffn_activation, float(dropout), seed, class_names)
```

## train.py

Adapt the `__main__` block to the user's data. `X, y = ..., ...` is a placeholder, not
runnable as written.

```python
"""train.py -- training loop and entry script for the Transformer."""
import numpy as np
import torch
import torch.nn as nn

from memory import database_init, load_memory, save_memory
from model import create_transformer_with_sqlite_memory


def train_transformer(model, X, y, epochs=50, lr=1e-3, weight_decay=1e-4, batch_size=32,
                      clip_norm=1.0, val_fraction=0.2, device="cpu", seed=42):
    """Standard supervised loop (one ordinary backward pass). Returns {'train': [...], 'val': [...]}."""
    cfg = model.config
    X = model.prepare_inputs(X)
    if cfg["task"] == "classification":
        y = torch.as_tensor(np.asarray(y))
        if y.ndim == 2 and y.shape[1] == cfg["output_dim"]:
            y = y.argmax(1)                              # accept one-hot
        y = y.reshape(-1).long()
        if len(y) and (y.min() < 0 or y.max() >= cfg["output_dim"]):
            raise ValueError(f"labels span {int(y.min())}..{int(y.max())}, "
                             f"but output_dim={cfg['output_dim']}")
        loss_fn = nn.CrossEntropyLoss()
    else:
        y = model.normalize_y(model.prepare_targets(y).to(model.y_mean.device))  # normalised space
        loss_fn = nn.MSELoss()
    if len(X) != len(y):
        raise ValueError(f"X has {len(X)} samples but y has {len(y)}")

    g = torch.Generator().manual_seed(seed)
    idx = torch.randperm(len(X), generator=g)
    n_val = int(len(X) * val_fraction) if len(X) >= 4 else 0   # too few samples: no validation
    val_idx, tr_idx = idx[:n_val], idx[n_val:]

    model.to(device)
    X, y = X.to(device), y.to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)  # fresh every run
    history = {"train": [], "val": []}
    for epoch in range(epochs):
        model.train()
        perm = tr_idx[torch.randperm(len(tr_idx), generator=g)]
        total = 0.0
        for i in range(0, len(perm), batch_size):
            b = perm[i:i + batch_size]
            opt.zero_grad()
            loss = loss_fn(model(X[b]), y[b])
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), clip_norm)
            opt.step()
            total += loss.item() * len(b)
        history["train"].append(total / len(perm))
        if n_val:
            model.eval()
            with torch.no_grad():
                history["val"].append(loss_fn(model(X[val_idx]), y[val_idx]).item())
        if (epoch + 1) % max(1, epochs // 10) == 0:
            v = f"  val {history['val'][-1]:.4f}" if n_val else ""
            print(f"epoch {epoch + 1}/{epochs}  train {history['train'][-1]:.4f}{v}")
    model.cpu()
    return history


if __name__ == "__main__":
    MEMORY_NAME = "my_task_v1"
    CONTINUE_TRAINING = False          # True = keep refining the loaded weights

    X, y = ..., ...                    # the user's data: X (N, F) tabular or (N, T, F) windows
    database_init()
    model = create_transformer_with_sqlite_memory(input_shape=X.shape[1:], output_dim=3,
                                                  task="classification")
    memory_loaded = load_memory(model, MEMORY_NAME)

    if not memory_loaded or CONTINUE_TRAINING:
        if not memory_loaded:
            model.fit_scaler(X, y)     # only on a fresh model, see Gotchas
        train_transformer(model, X, y, lr=1e-3 if not memory_loaded else 2e-4)
        save_memory(model, MEMORY_NAME)
    else:
        print("memory loaded, skipping training")

    probs = model.predict(X)
```

Defaults are ordinary Transformer practice: AdamW, learning rate 1e-3, weight decay 1e-4
(the framework's own default decay), gradient clipping at 1.0. When continuing from loaded
weights the template drops the learning rate to 2e-4 so the refined weights are adjusted
rather than overwritten.

## Choosing parameters

- **Size**: the defaults (`d_model=32`, `n_heads=4`, `n_layers=2`) match the framework's small
  setup and suit edge devices. For a few thousand samples or more, try `d_model` 64 to 128
  with 4 to 8 heads. For very small or low-memory targets, `n_layers=1` and `d_model` 16.
  `d_model` must be divisible by `n_heads`; the factory function raises if not.
- **`input_shape`**: always `X.shape[1:]`. Do not hard-code it.
- **`output_dim`**: number of classes, or number of regression targets (a forecast horizon
  counts as that many targets).
- **`class_names`**: pass it whenever the user has labels. It is saved in `config`, so a memory
  trained with another class order refuses to load instead of mislabelling.

## Initialisation

Xavier/Glorot uniform for every linear layer (attention projections already use it by
default in PyTorch), zero biases, default LayerNorm, and a small normal (std 0.02) for the
positional embedding. Initialisation only matters for a fresh model; a successful
`load_memory` overwrites it, which is why it stays out of `config`.

## When to prefer another architecture

Say this in one sentence when it applies, then still build what was asked:

- **Small tabular datasets** (roughly under a couple of thousand rows): Transformers are data
  hungry, and the framework's own README says so. Its alpha computation was the workaround for
  scarce data, and this plain version deliberately drops it. An MLP often matches or beats a
  Transformer here with far fewer parameters.
- **Ordered, step-by-step data** with a short history: an LSTM is a lighter alternative.
- **Many features** (hundreds): in feature-token mode attention costs grow with the square of
  `F`. Use an MLP, or arrange the features into `(T, F)` windows.

## Gotchas

- **Numeric input only.** There is no tokenizer, vocabulary or embedding table. Text or
  categorical data must be encoded to numbers first (one-hot, ordinal, target encoding) or
  handled by a different tool. Do not bolt on `nn.Embedding` unasked.
- **Fixed sequence length.** The positional embedding is sized by `input_shape`, and there is no
  padding mask. A different window length or feature count is a different structure, so it
  needs a new memory name.
- **`n_heads` and `norm_first` are structure.** Changing them alters no tensor shape, so the
  shape check cannot catch it, but the saved weights would silently mean something else.
  That is why they are in `config`, and `verify_tf.py` tests it.
- **Logits out, no softmax inside the model.** `CrossEntropyLoss` applies softmax itself;
  softmax happens only in `predict()`. Labels are class indices (one-hot is accepted by
  `train_transformer` and converted).
- **Fit the scaler once.** `x_mean` / `x_std` (and `y_mean` / `y_std` for regression) are
  buffers saved with the weights. Call `fit_scaler` only when `load_memory` returned `False`.
  In tabular mode statistics are per feature. In window mode they are per feature across all
  time steps. New data with a different range is a new task and deserves a new memory name.
- **Regression trains in normalised space**; `predict()` converts back to original units.
- **Pre-LayerNorm and `enable_nested_tensor=False`.** Pre-LN with a final LayerNorm trains
  stably on small data without a warmup schedule. Disabling nested tensors avoids a PyTorch
  warning and padding fast paths this fixed-length model does not need.
- **Dropout modules are always present**, so `state_dict` key names never depend on the dropout
  value the user picks.
- **Divergence.** If the loss goes NaN, lower the learning rate. `save_memory` refuses NaN or
  Inf weights, so a diverged run cannot overwrite a good memory.
- **Device.** Build, load, then `.to(device)` (done inside `train_transformer`). The optimizer
  is created fresh each run, after the load.
- **Data splits.** Under 4 samples there is no validation split; the split is random, not
  stratified. The loop keeps the final weights, with no early stopping.
- Needs PyTorch 2.x.

## Verify

Save as `verify_tf.py` next to the other files and run it. It covers the checklist in
`SKILL.md` plus scaler persistence, both input modes, the `n_heads` case and
original-unit regression output.

```python
"""Smoke test for the Transformer memory. Run from the folder containing memory.py, model.py, train.py."""
import os
import sqlite3

import numpy as np
import torch

from memory import database_init, save_memory, load_memory, MemoryIncompatibleError
from model import create_transformer_with_sqlite_memory
from train import train_transformer

DB = "verify_tf.db"
if os.path.exists(DB):
    os.remove(DB)
database_init(DB)


def same_weights(a, b):
    return all(torch.equal(x, y) for x, y in zip(a.state_dict().values(), b.state_dict().values()))


# classification on tabular rows (N, F): every feature is a token
X = np.random.randn(64, 6).astype("float32")
y = np.random.randint(0, 3, 64)
m1 = create_transformer_with_sqlite_memory(X.shape[1:], 3, d_model=16, n_heads=4, n_layers=1)
m1.fit_scaler(X)
train_transformer(m1, X, y, epochs=2)
save_memory(m1, "verify", DB)

# a different seed and dropout must NOT block loading (they are not structure)
m2 = create_transformer_with_sqlite_memory(X.shape[1:], 3, d_model=16, n_heads=4, n_layers=1,
                                           seed=7, dropout=0.0)
assert load_memory(m2, "verify", DB) is True
assert same_weights(m1, m2)                                   # includes scaler buffers
assert torch.allclose(m1.predict(X), m2.predict(X), atol=1e-6)

# d_model changes tensor shapes -> must raise, model untouched
m3 = create_transformer_with_sqlite_memory(X.shape[1:], 3, d_model=32, n_heads=4, n_layers=1)
before = {k: v.clone() for k, v in m3.state_dict().items()}
try:
    load_memory(m3, "verify", DB)
    raise AssertionError("expected MemoryIncompatibleError (d_model)")
except MemoryIncompatibleError:
    pass
assert all(torch.equal(before[k], v) for k, v in m3.state_dict().items())

# n_heads changes NO tensor shape, so only the config check can catch it
m4 = create_transformer_with_sqlite_memory(X.shape[1:], 3, d_model=16, n_heads=2, n_layers=1)
try:
    load_memory(m4, "verify", DB)
    raise AssertionError("expected MemoryIncompatibleError (n_heads)")
except MemoryIncompatibleError:
    pass

# versioning: second save keeps history, exactly one active row
save_memory(m1, "verify", DB)
rows = sqlite3.connect(DB).execute(
    "SELECT is_active FROM torch_weight_storage WHERE memory_name='verify' ORDER BY id").fetchall()
assert rows == [(0,), (1,)], rows

# windowed regression (N, T, F): original-unit predictions after a round trip
Xw = np.random.randn(48, 10, 3).astype("float32")
yw = (Xw.mean(axis=(1, 2)) * 40 + 500).reshape(-1, 1)
mw = create_transformer_with_sqlite_memory(Xw.shape[1:], 1, task="regression", d_model=16, n_heads=2, n_layers=1)
mw.fit_scaler(Xw, yw)
train_transformer(mw, Xw, yw, epochs=2)
save_memory(mw, "verify_window", DB)
mw2 = create_transformer_with_sqlite_memory(Xw.shape[1:], 1, task="regression", d_model=16, n_heads=2, n_layers=1)
assert load_memory(mw2, "verify_window", DB) is True
assert mw2.predict(Xw).mean().item() > 100, "regression output should be in original units"
assert torch.allclose(mw.predict(Xw), mw2.predict(Xw), atol=1e-4)

# wrong input shape raises instead of being sliced or padded
try:
    m1.predict(np.random.randn(4, 5).astype("float32"))
    raise AssertionError("expected ValueError")
except ValueError:
    pass

os.remove(DB)
print("Transformer memory checks passed")
```

Run it when a Python environment with torch is available. If not, say the checks were not
run. Note: the Transformer code in this reference was syntax-checked but not executed
against real PyTorch when this skill was drafted, so the first real run of `verify_tf.py`
is also the first test of the template itself.
