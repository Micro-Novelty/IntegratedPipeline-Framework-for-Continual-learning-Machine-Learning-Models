# MLP reference: `create_mlp_with_sqlite_memory()`

Read this when the user wants an MLP (feed-forward network on tabular or flat feature data,
classification or regression). It provides the model template for `model.py`, the training
loop and entry script for `train.py`, and a smoke test. The storage functions come from
`SKILL.md` and are not repeated here.

Contents: contract, model.py, train.py, choosing parameters, initialisation, gotchas, verify.

## Contract

`create_mlp_with_sqlite_memory()` returns an untrained CPU `nn.Module` whose `config` holds
structure only:

| key | meaning | present |
|---|---|---|
| `architecture` | always `"mlp"` | always |
| `task` | `"classification"` or `"regression"` | always |
| `input_dim` | number of input features | always |
| `hidden_layers` | list of hidden sizes, e.g. `[64, 32]` | always |
| `output_dim` | classes (classification) or targets/horizon (regression) | always |
| `activation` | `relu`, `leaky_relu`, `gelu`, `tanh`, `sigmoid` | always |
| `class_names` | ordered class labels | only if the user supplies them |

Deliberately **not** in `config`: dropout, init scheme, seed, learning rate, epochs. The user
can change those between runs and still load the same memory.

## model.py

```python
"""model.py -- MLP with SQLite memory support (He / Xavier-Glorot initialisation)."""
import numpy as np
import torch
import torch.nn as nn

_ACTIVATIONS = {"relu": nn.ReLU, "leaky_relu": nn.LeakyReLU, "gelu": nn.GELU,
                "tanh": nn.Tanh, "sigmoid": nn.Sigmoid}
_HE_FRIENDLY = {"relu", "leaky_relu", "gelu"}      # 'auto' picks He for these, Xavier otherwise


class MLPWithMemory(nn.Module):
    def __init__(self, input_dim, hidden_layers, output_dim, task, activation,
                 dropout, init, seed, class_names=None):
        super().__init__()
        if seed is not None:
            torch.manual_seed(seed)
        self.task, self.activation_name = task, activation

        # config = STRUCTURE ONLY (what must match for saved weights to fit).
        self.config = {"architecture": "mlp", "task": task, "input_dim": input_dim,
                       "hidden_layers": list(hidden_layers), "output_dim": output_dim,
                       "activation": activation}
        if class_names is not None:
            self.config["class_names"] = list(class_names)

        layers, prev = [], input_dim
        for units in hidden_layers:
            # Dropout is ALWAYS present (p=0.0 means off) so parameter names never shift
            # when the user changes dropout between runs.
            layers += [nn.Linear(prev, units), _ACTIVATIONS[activation](), nn.Dropout(dropout)]
            prev = units
        layers.append(nn.Linear(prev, output_dim))   # no activation: logits / raw values
        self.net = nn.Sequential(*layers)

        # Scaler statistics live in buffers so they are saved and restored with the weights.
        self.register_buffer("x_mean", torch.zeros(input_dim))
        self.register_buffer("x_std", torch.ones(input_dim))
        self.register_buffer("y_mean", torch.zeros(output_dim))   # used by regression only
        self.register_buffer("y_std", torch.ones(output_dim))
        self._init_weights(init)

    def _init_weights(self, init):
        scheme = init if init != "auto" else ("he" if self.activation_name in _HE_FRIENDLY else "xavier")
        linears = [m for m in self.net if isinstance(m, nn.Linear)]
        for layer in linears[:-1]:                                  # hidden layers
            if scheme == "he":
                nl = "leaky_relu" if self.activation_name == "leaky_relu" else "relu"
                nn.init.kaiming_normal_(layer.weight, nonlinearity=nl)
            else:
                gain = nn.init.calculate_gain(self.activation_name) \
                    if self.activation_name in ("tanh", "relu", "leaky_relu") else 1.0
                nn.init.xavier_uniform_(layer.weight, gain=gain)
            nn.init.zeros_(layer.bias)
        nn.init.xavier_uniform_(linears[-1].weight)                 # linear output layer
        nn.init.zeros_(linears[-1].bias)

    @torch.no_grad()
    def fit_scaler(self, X, y=None):
        """Standardise inputs (and regression targets). Call ONLY on a fresh model,
        never after load_memory: the loaded weights were trained against the old statistics."""
        X = _as_2d(X, self.config["input_dim"])
        self.x_mean.copy_(X.mean(0))
        self.x_std.copy_(X.std(0, unbiased=False).clamp_min(1e-8))
        if self.task == "regression" and y is not None:
            y = _as_targets(y, self.config["output_dim"])
            self.y_mean.copy_(y.mean(0))
            self.y_std.copy_(y.std(0, unbiased=False).clamp_min(1e-8))

    def normalize_y(self, y):
        return (y - self.y_mean) / self.y_std

    def forward(self, x):                        # classification: logits; regression: normalised values
        return self.net((x - self.x_mean) / self.x_std)

    @torch.no_grad()
    def predict(self, X):
        """classification -> class probabilities; regression -> values in original units."""
        was_training = self.training
        self.eval()
        X = _as_2d(X, self.config["input_dim"]).to(self.x_mean.device)
        out = self(X)
        self.train(was_training)
        return torch.softmax(out, dim=1) if self.task == "classification" else out * self.y_std + self.y_mean


def _as_2d(X, input_dim):
    X = torch.as_tensor(np.asarray(X), dtype=torch.float32)
    if X.ndim == 1:
        X = X.unsqueeze(1)
    if X.ndim > 2:
        X = X.flatten(1)
    if X.shape[1] != input_dim:      # raise, never slice or pad
        raise ValueError(f"X has {X.shape[1]} features but the model expects input_dim={input_dim}")
    return X


def _as_targets(y, output_dim):
    y = torch.as_tensor(np.asarray(y), dtype=torch.float32)
    y = y.reshape(len(y), -1)
    if y.shape[1] != output_dim:
        raise ValueError(f"y has {y.shape[1]} columns but the model expects output_dim={output_dim}")
    return y


def create_mlp_with_sqlite_memory(input_dim, output_dim, hidden_layers=(64, 32),
                                  task="classification", activation="relu",
                                  dropout=0.0, init="auto", seed=42, class_names=None):
    """Build an MLP that satisfies the save_memory / load_memory contract (CPU, untrained)."""
    if task not in ("classification", "regression"):
        raise ValueError("task must be 'classification' or 'regression'")
    if activation not in _ACTIVATIONS:
        raise ValueError(f"activation must be one of {sorted(_ACTIVATIONS)}")
    if init not in ("auto", "he", "xavier"):
        raise ValueError("init must be 'auto', 'he' or 'xavier'")
    if input_dim < 1 or output_dim < 1 or any(h < 1 for h in hidden_layers):
        raise ValueError("all layer sizes must be positive integers")
    if task == "classification" and output_dim < 2:
        raise ValueError("classification needs output_dim >= 2 (one logit per class)")
    if class_names is not None and len(class_names) != output_dim:
        raise ValueError("class_names must have exactly output_dim entries")
    return MLPWithMemory(int(input_dim), [int(h) for h in hidden_layers], int(output_dim),
                         task, activation, float(dropout), init, seed, class_names)
```

## train.py

Adapt the `__main__` block to the user's data. `X, y = ..., ...` is a placeholder, not
runnable as written.

```python
"""train.py -- training loop and entry script for the MLP."""
import numpy as np
import torch
import torch.nn as nn

from memory import database_init, load_memory, save_memory
from model import create_mlp_with_sqlite_memory, _as_2d, _as_targets


def train_mlp(model, X, y, epochs=200, lr=0.01, momentum=0.9, batch_size=32,
              clip_norm=5.0, val_fraction=0.2, device="cpu", seed=42):
    """Plain supervised loop. Returns {'train': [...], 'val': [...]} loss history."""
    cfg = model.config
    X = _as_2d(X, cfg["input_dim"])
    if cfg["task"] == "classification":
        y = torch.as_tensor(np.asarray(y))
        if y.ndim == 2 and y.shape[1] == cfg["output_dim"]:
            y = y.argmax(1)                              # accept one-hot
        y = y.reshape(-1).long()
        if len(y) and (y.min() < 0 or y.max() >= cfg["output_dim"]):
            raise ValueError(f"labels span {int(y.min())}..{int(y.max())}, "
                             f"but output_dim={cfg['output_dim']}")
        loss_fn = nn.CrossEntropyLoss()
    else:
        y = _as_targets(y, cfg["output_dim"])
        y = model.normalize_y(y.to(model.y_mean.device))   # train in normalised space
        loss_fn = nn.MSELoss()
    if len(X) != len(y):
        raise ValueError(f"X has {len(X)} samples but y has {len(y)}")

    g = torch.Generator().manual_seed(seed)
    idx = torch.randperm(len(X), generator=g)
    n_val = int(len(X) * val_fraction) if len(X) >= 4 else 0   # too few samples: no validation
    val_idx, tr_idx = idx[:n_val], idx[n_val:]

    model.to(device)
    X, y = X.to(device), y.to(device)
    opt = torch.optim.SGD(model.parameters(), lr=lr, momentum=momentum)   # fresh optimizer every run
    history = {"train": [], "val": []}
    for epoch in range(epochs):
        model.train()
        perm = tr_idx[torch.randperm(len(tr_idx), generator=g)]
        total = 0.0
        for i in range(0, len(perm), batch_size):
            b = perm[i:i + batch_size]
            opt.zero_grad()
            loss = loss_fn(model(X[b]), y[b])
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), clip_norm)
            opt.step()
            total += loss.item() * len(b)
        history["train"].append(total / len(perm))
        if n_val:
            model.eval()
            with torch.no_grad():
                history["val"].append(loss_fn(model(X[val_idx]), y[val_idx]).item())
        if (epoch + 1) % max(1, epochs // 10) == 0:
            v = f"  val {history['val'][-1]:.4f}" if n_val else ""
            print(f"epoch {epoch + 1}/{epochs}  train {history['train'][-1]:.4f}{v}")
    model.cpu()
    return history


if __name__ == "__main__":
    MEMORY_NAME = "my_task_v1"
    CONTINUE_TRAINING = False          # True = keep refining the loaded weights

    X, y = ..., ...                    # the user's data
    database_init()
    model = create_mlp_with_sqlite_memory(input_dim=X.shape[-1], output_dim=3,
                                          hidden_layers=(64, 32), task="classification")
    memory_loaded = load_memory(model, MEMORY_NAME)

    if not memory_loaded or CONTINUE_TRAINING:
        if not memory_loaded:
            model.fit_scaler(X, y)     # only on a fresh model, see Gotchas
        train_mlp(model, X, y, lr=0.01 if not memory_loaded else 0.002)
        save_memory(model, MEMORY_NAME)
    else:
        print("memory loaded, skipping training")

    probs = model.predict(X)
```

Defaults mirror the framework's README example: SGD with momentum 0.9, learning rate 0.01,
gradient-norm clipping at 5.0. Swapping in `torch.optim.Adam` is a one-line change if the
user prefers it. When continuing from loaded weights, use a smaller learning rate (the
template drops it to 0.002) so the refined weights are adjusted rather than thrown away.

## Choosing parameters

- **`hidden_layers`**: infer from data size when the user gives none. Under ~1,000 samples,
  `(32, 16)`; a few thousand and up, `(64, 32)` or `(128, 64)`. Keep it small for edge or
  low-memory targets, which is the framework's audience.
- **`task`**: regression when the target is a continuous number, classification when it is a
  category. For regression set `output_dim` to the number of targets (forecast horizon
  included, as in the framework's regression example where horizon equals the label count).
- **`activation`**: `relu` unless asked. `tanh` or `sigmoid` only on request.
- **`class_names`**: pass it whenever the user has a label list. It is saved in `config`, so a
  memory trained with a different class order refuses to load instead of mislabelling.

## Initialisation

Weights use PyTorch's standard schemes, chosen from the activation (`init="auto"`):

- **He (Kaiming normal)** for `relu`, `leaky_relu`, `gelu`. It scales variance for rectifiers
  so signals do not shrink layer by layer.
- **Xavier/Glorot uniform** for `tanh` and `sigmoid`, with the matching gain for `tanh`.
- The final linear layer always uses Xavier, and every bias starts at zero.

The user can force `init="he"` or `init="xavier"`. Initialisation only matters for a fresh
model; once `load_memory` succeeds the saved weights overwrite it, so it is correctly kept
out of `config`.

The framework's AWE (geometric weight shaping) and quantization-aware training are
intentionally **not** ported. If the user asks for quantization or eigenvalue-based
initialisation, say it is outside this skill rather than improvising a version.

## Gotchas

- **Logits out, no softmax inside the model.** `CrossEntropyLoss` expects raw logits and
  applies softmax itself. Softmax happens only in `predict()`. The last layer has no
  activation for either task, as in the framework.
- **Labels are class indices.** The framework one-hot encodes `y`; PyTorch's loss wants
  integer indices. `train_mlp` accepts either and converts.
- **`input_dim` is explicit.** Do not use `nn.LazyLinear`. Its parameters do not exist until
  the first forward pass, so `load_memory` could neither check shapes nor load into them.
- **Dropout module is always present** (`p=0.0` means off), so the keys in `state_dict`
  (`net.0`, `net.3`, ...) stay identical whatever dropout the user picks later.
- **Fit the scaler once.** `x_mean` / `x_std` (and `y_mean` / `y_std` for regression) are
  buffers saved with the weights. Call `fit_scaler` only when `load_memory` returned
  `False`. Refitting on new data after a load would shift the inputs the loaded weights were
  trained on. If new data genuinely has a different range, that is a new task and deserves a
  new memory name.
- **Shapes raise, they are never repaired.** A feature-count or label-range mismatch is a
  `ValueError` naming the problem, never a silent slice or pad. Data with more than two
  dimensions is flattened per sample.
- **Regression is trained in normalised space** and `predict()` converts back to original
  units. Report errors in original units, not normalised ones.
- **Small data.** Under 4 samples there is no validation split. The split is random, not
  stratified, so very rare classes may be missing from validation. The loop keeps the final
  weights and does not early-stop; validation loss is printed for the user to judge.
- **Device.** Build, load, then `.to(device)` (the template does this inside `train_mlp`).
  The optimizer is created fresh each run, after the load, as the framework does.
- **Not ported:** the framework's per-class `error_counts` / `pred_counts` penalty tracking.
  It is part of its prediction pipeline, not of weight memory.

## Verify

Save as `verify_mlp.py` next to the other files and run it. It covers the checklist in
`SKILL.md` plus scaler persistence and regression units.

```python
"""Smoke test for the MLP memory. Run from the folder containing memory.py, model.py, train.py."""
import os
import sqlite3

import numpy as np
import torch

from memory import database_init, save_memory, load_memory, MemoryIncompatibleError
from model import create_mlp_with_sqlite_memory
from train import train_mlp

DB = "verify_mlp.db"
if os.path.exists(DB):
    os.remove(DB)
database_init(DB)

# classification round trip
X = np.random.randn(64, 5).astype("float32")
y = np.random.randint(0, 3, 64)
m1 = create_mlp_with_sqlite_memory(5, 3, (8, 4))
m1.fit_scaler(X)
train_mlp(m1, X, y, epochs=2)
save_memory(m1, "verify", DB)

# a different seed and dropout must NOT block loading (they are not structure)
m2 = create_mlp_with_sqlite_memory(5, 3, (8, 4), seed=7, dropout=0.3)
assert load_memory(m2, "verify", DB) is True
for (k, a), (_, b) in zip(m1.state_dict().items(), m2.state_dict().items()):
    assert torch.equal(a, b), f"{k} differs after load"          # includes scaler buffers
assert torch.allclose(m1.predict(X), m2.predict(X))

# a different hidden size must raise and leave the model untouched
m3 = create_mlp_with_sqlite_memory(5, 3, (16, 4))
before = {k: v.clone() for k, v in m3.state_dict().items()}
try:
    load_memory(m3, "verify", DB)
    raise AssertionError("expected MemoryIncompatibleError")
except MemoryIncompatibleError:
    pass
assert all(torch.equal(before[k], v) for k, v in m3.state_dict().items())

# versioning: second save keeps history, exactly one active row
save_memory(m1, "verify", DB)
rows = sqlite3.connect(DB).execute(
    "SELECT is_active FROM torch_weight_storage WHERE memory_name='verify' ORDER BY id").fetchall()
assert rows == [(0,), (1,)], rows

# regression: predictions come back in original units
Xr = np.random.randn(64, 4).astype("float32")
yr = (Xr @ np.array([1.0, 2.0, -1.0, 0.5], dtype="float32") * 50 + 1000).reshape(-1, 1)
mr = create_mlp_with_sqlite_memory(4, 1, (16,), task="regression")
mr.fit_scaler(Xr, yr)
train_mlp(mr, Xr, yr, epochs=2)
assert mr.predict(Xr).mean().item() > 100, "regression output should be in original units"

os.remove(DB)
print("MLP memory checks passed")
```

Run it when a Python environment with torch is available. If it is not, say the checks were
not run. Note: the MLP code in this reference was syntax-checked but not executed against
real PyTorch when this skill was drafted, so the first real run of `verify_mlp.py` is also
the first test of the template itself.
