"""Smoke test for the LSTM memory. Run from the folder containing memory.py, model.py, train.py."""
import os
import sqlite3
from contextlib import closing

import numpy as np
import torch

from memory import database_init, save_memory, load_memory, list_memories, MemoryIncompatibleError
from model_lstm import create_lstm_with_sqlite_memory
from training_lstm import train_lstm

import memory
assert os.path.isabs(memory.DB_PATH), "DB_PATH must not depend on the working directory"

DB = "verify_lstm.db"
if os.path.exists(DB):
    os.remove(DB)
database_init(DB)


def same_weights(a, b):
    return all(torch.equal(x, y) for x, y in zip(a.state_dict().values(), b.state_dict().values()))


def must_raise(model, name):
    before = {k: v.clone() for k, v in model.state_dict().items()}
    try:
        load_memory(model, name, DB)
        raise AssertionError("expected MemoryIncompatibleError")
    except MemoryIncompatibleError:
        pass
    assert all(torch.equal(before[k], v) for k, v in model.state_dict().items())


# classification on sequences (N, T, F), two layers so between-layer dropout is active
X = np.random.randn(64, 12, 3).astype("float32")
y = np.random.randint(0, 3, 64)
m1 = create_lstm_with_sqlite_memory(3, 3, hidden_size=8, num_layers=2, dropout=0.3)
m1.fit_scaler(X)
train_lstm(m1, X, y, epochs=2)
save_memory(m1, "verify", DB)

# a different seed and dropout must NOT block loading (they are not structure)
m2 = create_lstm_with_sqlite_memory(3, 3, hidden_size=8, num_layers=2, dropout=0.0, seed=7)
assert load_memory(m2, "verify", DB) is True
assert same_weights(m1, m2)                                   # includes scaler buffers
assert torch.allclose(m1.predict(X), m2.predict(X), atol=1e-6)

# sequence length is not structure: a longer window still predicts
assert m2.predict(np.random.randn(5, 30, 3).astype("float32")).shape == (5, 3)

# structural differences must raise and leave the model untouched
must_raise(create_lstm_with_sqlite_memory(3, 3, hidden_size=16, num_layers=2), "verify")
must_raise(create_lstm_with_sqlite_memory(3, 3, hidden_size=8, num_layers=1), "verify")
must_raise(create_lstm_with_sqlite_memory(3, 3, hidden_size=8, num_layers=2, bidirectional=True), "verify")

# versioning: second save keeps history, exactly one active row
first_weights = {k: v.clone() for k, v in m1.state_dict().items()}
with torch.no_grad():
    next(m1.parameters()).add_(1.0)              # make version 2 differ from version 1
save_memory(m1, "verify", DB)
with closing(sqlite3.connect(DB)) as conn:     # close it: Windows cannot delete an open database
    rows = conn.execute(
        "SELECT is_active FROM torch_weight_storage WHERE memory_name='verify' ORDER BY id").fetchall()
assert rows == [(0,), (1,)], rows
 
# list_memories: both versions, newest first, no weights loaded
versions = list_memories("verify", db_path=DB)
assert [v["is_active"] for v in versions] == [True, False], versions
assert versions[0]["id"] > versions[1]["id"] and versions[0]["size_bytes"] > 0
assert list_memories("no_such_memory", db_path=DB) == []
 
# load_memory(version=...) restores an OLD version exactly; the default still loads the active one
old = create_lstm_with_sqlite_memory(3, 3, hidden_size=8, num_layers=2)
assert load_memory(old, "verify", DB, version=versions[1]["id"]) is True
assert all(torch.equal(first_weights[k], v) for k, v in old.state_dict().items())
cur = create_lstm_with_sqlite_memory(3, 3, hidden_size=8, num_layers=2)
assert load_memory(cur, "verify", DB) is True
assert same_weights(cur, m1) and not same_weights(cur, old)
try:
    load_memory(create_lstm_with_sqlite_memory(3, 3, hidden_size=8, num_layers=2), "verify", DB, version=99999)
    raise AssertionError("expected ValueError for a version that does not exist")
except ValueError:
    pass
 
# rollback = load the old version, save again: it becomes the new active version, history stays
save_memory(old, "verify", DB)
assert [v["is_active"] for v in list_memories("verify", db_path=DB)] == [True, False, False]

# univariate regression on (N, T) windows with a tail split: original-unit predictions
Xu = np.random.randn(60, 10).astype("float32")
yu = (Xu.mean(axis=1) * 40 + 500).reshape(-1, 1)
mu = create_lstm_with_sqlite_memory(1, 1, task="regression", hidden_size=8)
mu.fit_scaler(Xu, yu)
train_lstm(mu, Xu, yu, epochs=2, val_split="tail")
save_memory(mu, "verify_uni", DB)
mu2 = create_lstm_with_sqlite_memory(1, 1, task="regression", hidden_size=8)
assert load_memory(mu2, "verify_uni", DB) is True
assert mu2.predict(Xu).mean().item() > 100, "regression output should be in original units"
assert torch.allclose(mu.predict(Xu), mu2.predict(Xu), atol=1e-4)

# wrong feature count raises instead of being sliced or padded
try:
    m1.predict(np.random.randn(4, 12, 5).astype("float32"))
    raise AssertionError("expected ValueError")
except ValueError:
    pass

try:
    os.remove(DB)
except PermissionError:      # Windows: a handle is still open; the checks above already passed
    print(f"note: could not delete {DB}, remove it by hand")
print("LSTM memory checks passed")