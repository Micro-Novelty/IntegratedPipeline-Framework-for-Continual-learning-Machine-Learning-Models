"""Smoke test for the MLP memory. Run from the folder containing memory.py, model.py, train.py."""
import os
import sqlite3
from contextlib import closing

import numpy as np
import torch

from memory import database_init, save_memory, load_memory, list_memories, MemoryIncompatibleError
from model_mlp import create_mlp_with_sqlite_memory
from training_mlp import train_mlp

import memory
assert os.path.isabs(memory.DB_PATH), "DB_PATH must not depend on the working directory"

DB = "verify_mlp.db"
if os.path.exists(DB):
    os.remove(DB)
database_init(DB)

def same_weights(a, b):
    return all(torch.equal(x, y) for x, y in zip(a.state_dict().values(), b.state_dict().values()))

# classification round trip
X = np.random.randn(64, 5).astype("float32")
y = np.random.randint(0, 3, 64)
m1 = create_mlp_with_sqlite_memory(5, 3, (8, 4))
m1.fit_scaler(X)
train_mlp(m1, X, y, epochs=2)
save_memory(m1, "verify", DB)

# a different seed and dropout must NOT block loading (they are not structure)
m2 = create_mlp_with_sqlite_memory(5, 3, (8, 4), seed=7, dropout=0.3)
assert load_memory(m2, "verify", DB) is True
for (k, a), (_, b) in zip(m1.state_dict().items(), m2.state_dict().items()):
    assert torch.equal(a, b), f"{k} differs after load"          # includes scaler buffers
assert torch.allclose(m1.predict(X), m2.predict(X))

# a different hidden size must raise and leave the model untouched
m3 = create_mlp_with_sqlite_memory(5, 3, (16, 4))
before = {k: v.clone() for k, v in m3.state_dict().items()}
try:
    load_memory(m3, "verify", DB)
    raise AssertionError("expected MemoryIncompatibleError")
except MemoryIncompatibleError:
    pass
assert all(torch.equal(before[k], v) for k, v in m3.state_dict().items())

# versioning: second save keeps history, exactly one active row
first_weights = {k: v.clone() for k, v in m1.state_dict().items()}
with torch.no_grad():
    next(m1.parameters()).add_(1.0)              # make version 2 differ from version 1
save_memory(m1, "verify", DB)
with closing(sqlite3.connect(DB)) as conn:     # close it: Windows cannot delete an open database
    rows = conn.execute(
        "SELECT is_active FROM torch_weight_storage WHERE memory_name='verify' ORDER BY id").fetchall()
assert rows == [(0,), (1,)], rows
 
# list_memories: both versions, newest first, no weights loaded
versions = list_memories("verify", db_path=DB)
assert [v["is_active"] for v in versions] == [True, False], versions
assert versions[0]["id"] > versions[1]["id"] and versions[0]["size_bytes"] > 0
assert list_memories("no_such_memory", db_path=DB) == []
 
# load_memory(version=...) restores an OLD version exactly; the default still loads the active one
old = create_mlp_with_sqlite_memory(5, 3, (8, 4))
assert load_memory(old, "verify", DB, version=versions[1]["id"]) is True
assert all(torch.equal(first_weights[k], v) for k, v in old.state_dict().items())
cur = create_mlp_with_sqlite_memory(5, 3, (8, 4))
assert load_memory(cur, "verify", DB) is True
assert same_weights(cur, m1) and not same_weights(cur, old)
try:
    load_memory(create_mlp_with_sqlite_memory(5, 3, (8, 4)), "verify", DB, version=99999)
    raise AssertionError("expected ValueError for a version that does not exist")
except ValueError:
    pass
 
# rollback = load the old version, save again: it becomes the new active version, history stays
save_memory(old, "verify", DB)
assert [v["is_active"] for v in list_memories("verify", db_path=DB)] == [True, False, False]
 

# regression: predictions come back in original units
Xr = np.random.randn(64, 4).astype("float32")
yr = (Xr @ np.array([1.0, 2.0, -1.0, 0.5], dtype="float32") * 50 + 1000).reshape(-1, 1)
mr = create_mlp_with_sqlite_memory(4, 1, (16,), task="regression")
mr.fit_scaler(Xr, yr)
train_mlp(mr, Xr, yr, epochs=2)
assert mr.predict(Xr).mean().item() > 100, "regression output should be in original units"

try:
    os.remove(DB)
except PermissionError:      # Windows: a handle is still open; the checks above already passed
    print(f"note: could not delete {DB}, remove it by hand")
print("MLP memory checks passed")