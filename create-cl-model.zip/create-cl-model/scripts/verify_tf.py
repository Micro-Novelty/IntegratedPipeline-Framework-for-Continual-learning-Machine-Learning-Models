"""Smoke test for the Transformer memory. Run from the folder containing memory.py, model.py, train.py."""
import os
import sqlite3
from contextlib import closing

import numpy as np
import torch

from memory import database_init, save_memory, load_memory, list_memories, MemoryIncompatibleError
from model_transformer import create_transformer_with_sqlite_memory
from train_tf import train_transformer

import memory
assert os.path.isabs(memory.DB_PATH), "DB_PATH must not depend on the working directory"

DB = "verify_tf.db"
if os.path.exists(DB):
    os.remove(DB)
database_init(DB)


def same_weights(a, b):
    return all(torch.equal(x, y) for x, y in zip(a.state_dict().values(), b.state_dict().values()))


# classification on tabular rows (N, F): every feature is a token
X = np.random.randn(64, 6).astype("float32")
y = np.random.randint(0, 3, 64)
m1 = create_transformer_with_sqlite_memory(X.shape[1:], 3, d_model=16, n_heads=4, n_layers=1)
m1.fit_scaler(X)
train_transformer(m1, X, y, epochs=2)
save_memory(m1, "verify", DB)

# a different seed and dropout must NOT block loading (they are not structure)
m2 = create_transformer_with_sqlite_memory(X.shape[1:], 3, d_model=16, n_heads=4, n_layers=1,
                                           seed=7, dropout=0.0)
assert load_memory(m2, "verify", DB) is True
assert same_weights(m1, m2)                                   # includes scaler buffers
assert torch.allclose(m1.predict(X), m2.predict(X), atol=1e-6)

# d_model changes tensor shapes -> must raise, model untouched
m3 = create_transformer_with_sqlite_memory(X.shape[1:], 3, d_model=32, n_heads=4, n_layers=1)
before = {k: v.clone() for k, v in m3.state_dict().items()}
try:
    load_memory(m3, "verify", DB)
    raise AssertionError("expected MemoryIncompatibleError (d_model)")
except MemoryIncompatibleError:
    pass
assert all(torch.equal(before[k], v) for k, v in m3.state_dict().items())

# n_heads changes NO tensor shape, so only the config check can catch it
m4 = create_transformer_with_sqlite_memory(X.shape[1:], 3, d_model=16, n_heads=2, n_layers=1)
try:
    load_memory(m4, "verify", DB)
    raise AssertionError("expected MemoryIncompatibleError (n_heads)")
except MemoryIncompatibleError:
    pass

# versioning: second save keeps history, exactly one active row
first_weights = {k: v.clone() for k, v in m1.state_dict().items()}
with torch.no_grad():
    next(m1.parameters()).add_(1.0)              # make version 2 differ from version 1
save_memory(m1, "verify", DB)
with closing(sqlite3.connect(DB)) as conn:     # close it: Windows cannot delete an open database
    rows = conn.execute(
        "SELECT is_active FROM torch_weight_storage WHERE memory_name='verify' ORDER BY id").fetchall()
assert rows == [(0,), (1,)], rows
 
# list_memories: both versions, newest first, no weights loaded
versions = list_memories("verify", db_path=DB)
assert [v["is_active"] for v in versions] == [True, False], versions
assert versions[0]["id"] > versions[1]["id"] and versions[0]["size_bytes"] > 0
assert list_memories("no_such_memory", db_path=DB) == []
 
# load_memory(version=...) restores an OLD version exactly; the default still loads the active one
old = create_transformer_with_sqlite_memory(X.shape[1:], 3, d_model=16, n_heads=4, n_layers=1)
assert load_memory(old, "verify", DB, version=versions[1]["id"]) is True
assert all(torch.equal(first_weights[k], v) for k, v in old.state_dict().items())
cur = create_transformer_with_sqlite_memory(X.shape[1:], 3, d_model=16, n_heads=4, n_layers=1)
assert load_memory(cur, "verify", DB) is True
assert same_weights(cur, m1) and not same_weights(cur, old)
try:
    load_memory(create_transformer_with_sqlite_memory(X.shape[1:], 3, d_model=16, n_heads=4, n_layers=1), "verify", DB, version=99999)
    raise AssertionError("expected ValueError for a version that does not exist")
except ValueError:
    pass
 
# rollback = load the old version, save again: it becomes the new active version, history stays
save_memory(old, "verify", DB)
assert [v["is_active"] for v in list_memories("verify", db_path=DB)] == [True, False, False]

# windowed regression (N, T, F): original-unit predictions after a round trip
Xw = np.random.randn(48, 10, 3).astype("float32")
yw = (Xw.mean(axis=(1, 2)) * 40 + 500).reshape(-1, 1)
mw = create_transformer_with_sqlite_memory(Xw.shape[1:], 1, task="regression", d_model=16, n_heads=2, n_layers=1)
mw.fit_scaler(Xw, yw)
train_transformer(mw, Xw, yw, epochs=2)
save_memory(mw, "verify_window", DB)
mw2 = create_transformer_with_sqlite_memory(Xw.shape[1:], 1, task="regression", d_model=16, n_heads=2, n_layers=1)
assert load_memory(mw2, "verify_window", DB) is True
assert mw2.predict(Xw).mean().item() > 100, "regression output should be in original units"
assert torch.allclose(mw.predict(Xw), mw2.predict(Xw), atol=1e-4)

# wrong input shape raises instead of being sliced or padded
try:
    m1.predict(np.random.randn(4, 5).astype("float32"))
    raise AssertionError("expected ValueError")
except ValueError:
    pass

try:
    os.remove(DB)
except PermissionError:      # Windows: a handle is still open; the checks above already passed
    print(f"note: could not delete {DB}, remove it by hand")
print("Transformer memory checks passed")